import { useMemo } from 'react';
import {
  Box, Grid, Card, CardContent, Typography, Avatar, Stack, Chip, List,
  ListItem, ListItemAvatar, ListItemText, Divider,
} from '@mui/material';
import GroupRounded from '@mui/icons-material/GroupRounded';
import GridViewRounded from '@mui/icons-material/GridViewRounded';
import MailRounded from '@mui/icons-material/MailRounded';
import CategoryRounded from '@mui/icons-material/CategoryRounded';
import RateReviewRounded from '@mui/icons-material/RateReviewRounded';
import { useData } from '../../context/DataContext';
import StatCard from '../../components/DashboardCards/StatCard';
import BarChartCard from '../../components/Charts/BarChartCard';
import PieChartCard from '../../components/Charts/PieChartCard';
import LineChartCard from '../../components/Charts/LineChartCard';
import PageHeader from '../../components/PageHeader';
import { gradients } from '../../theme/theme';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export default function AdminDashboard() {
  const { users, services, categories, messages, reviews } = useData();

  const stats = [
    { title: 'Total users', value: users.length, icon: <GroupRounded />, gradient: gradients.primary, trend: '+12%', subtitle: 'vs last month' },
    { title: 'Services', value: services.length, icon: <GridViewRounded />, gradient: gradients.accent, trend: '+8%', subtitle: 'vs last month' },
    { title: 'Messages', value: messages.length, icon: <MailRounded />, gradient: gradients.success, trend: '+5%', subtitle: 'vs last month' },
    { title: 'Categories', value: categories.length, icon: <CategoryRounded />, gradient: gradients.primary, subtitle: 'Active' },
  ];

  const byCategory = useMemo(
    () => categories.map((c) => ({ name: c.name.split(' ')[0], value: services.filter((s) => s.categoryId === c.id).length })),
    [categories, services],
  );

  const reviewStatus = useMemo(() => {
    const counts = reviews.reduce((acc, r) => ({ ...acc, [r.status]: (acc[r.status] ?? 0) + 1 }), {});
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [reviews]);

  const messagesByMonth = useMemo(() => {
    const counts = Array(12).fill(0);
    messages.forEach((m) => {
      const month = Number((m.createdAt ?? '2025-01').slice(5, 7)) - 1;
      if (month >= 0 && month < 12) counts[month] += 1;
    });
    return MONTHS.map((name, i) => ({ name, value: counts[i] }));
  }, [messages]);

  const pendingReviews = reviews.filter((r) => r.status === 'pending');
  const recentMessages = messages.slice(0, 5);

  return (
    <Box>
      <PageHeader title="Admin dashboard" subtitle="Platform analytics and live activity at a glance." />

      <Grid container spacing={3}>
        {stats.map((s) => (
          <Grid key={s.title} size={{ xs: 12, sm: 6, md: 3 }}>
            <StatCard {...s} />
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={3} sx={{ mt: 0 }}>
        <Grid size={{ xs: 12, md: 8 }}>
          <BarChartCard title="Services by category" subtitle="Distribution across the catalog" data={byCategory} />
        </Grid>
        <Grid size={{ xs: 12, md: 4 }}>
          <PieChartCard title="Reviews" subtitle="Moderation status" data={reviewStatus} />
        </Grid>
      </Grid>

      <Grid container spacing={3} sx={{ mt: 0 }}>
        <Grid size={{ xs: 12, md: 8 }}>
          <LineChartCard title="Messages over time" subtitle="Monthly inbound volume" data={messagesByMonth} />
        </Grid>
        <Grid size={{ xs: 12, md: 4 }}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1 }}>
                <Typography variant="h6" sx={{ fontWeight: 700 }}>Pending reviews</Typography>
                <Chip size="small" color="warning" label={pendingReviews.length} />
              </Stack>
              <List dense disablePadding>
                {pendingReviews.length === 0 && (
                  <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>All caught up — no pending reviews.</Typography>
                )}
                {pendingReviews.slice(0, 5).map((r, i) => (
                  <Box key={r.id}>
                    <ListItem disableGutters>
                      <ListItemAvatar>
                        <Avatar sx={{ background: gradients.accent, width: 36, height: 36 }}><RateReviewRounded fontSize="small" /></Avatar>
                      </ListItemAvatar>
                      <ListItemText primary={r.author} secondary={r.comment} primaryTypographyProps={{ fontWeight: 600, variant: 'body2' }} secondaryTypographyProps={{ noWrap: true }} />
                    </ListItem>
                    {i < Math.min(pendingReviews.length, 5) - 1 && <Divider component="li" />}
                  </Box>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Box sx={{ mt: 3 }}>
        <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>Recent messages</Typography>
        <Card>
          <List disablePadding>
            {recentMessages.map((m, i) => (
              <Box key={m.id}>
                <ListItem>
                  <ListItemAvatar>
                    <Avatar sx={{ background: gradients.primary }}><MailRounded /></Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={<Stack direction="row" spacing={1} alignItems="center"><Typography variant="subtitle2" sx={{ fontWeight: 700 }}>{m.subject}</Typography><Chip size="small" label={m.status} sx={{ textTransform: 'capitalize' }} /></Stack>}
                    secondary={`${m.fromName} — ${m.body}`}
                    secondaryTypographyProps={{ noWrap: true }}
                  />
                </ListItem>
                {i < recentMessages.length - 1 && <Divider component="li" />}
              </Box>
            ))}
          </List>
        </Card>
      </Box>
    </Box>
  );
}
