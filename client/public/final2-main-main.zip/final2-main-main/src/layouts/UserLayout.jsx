import { useMemo, useState } from 'react';
import { Box, Container } from '@mui/material';
import { Outlet, useLocation } from 'react-router-dom';
import HomeRounded from '@mui/icons-material/HomeRounded';
import DashboardRounded from '@mui/icons-material/DashboardRounded';
import GridViewRounded from '@mui/icons-material/GridViewRounded';
import FavoriteRounded from '@mui/icons-material/FavoriteRounded';
import MailRounded from '@mui/icons-material/MailRounded';
import PersonRounded from '@mui/icons-material/PersonRounded';
import Navbar from '../components/Navbar/Navbar';
import Sidebar from '../components/Sidebar/Sidebar';
import { gradients } from '../theme/theme';

const items = [
  { label: 'Home', to: '/app', end: true, icon: <HomeRounded /> },
  { label: 'Dashboard', to: '/app/dashboard', icon: <DashboardRounded /> },
  { label: 'Services', to: '/app/services', icon: <GridViewRounded /> },
  { label: 'Favorites', to: '/app/favorites', icon: <FavoriteRounded /> },
  { label: 'Messages', to: '/app/messages', icon: <MailRounded /> },
  { label: 'Profile', to: '/app/profile', icon: <PersonRounded /> },
];

const titles = {
  '/app': 'Home',
  '/app/dashboard': 'Dashboard',
  '/app/services': 'Services',
  '/app/favorites': 'Favorites',
  '/app/messages': 'Messages',
  '/app/profile': 'Profile',
};

export default function UserLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const title = useMemo(() => titles[location.pathname] ?? 'Workspace', [location.pathname]);

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', background: (t) => (t.palette.mode === 'dark' ? gradients.darkPage : gradients.lightPage) }}>
      <Sidebar items={items} mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} label="Workspace" />
      <Box sx={{ flexGrow: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <Navbar title={title} onMenuClick={() => setMobileOpen(true)} />
        <Container maxWidth="xl" sx={{ py: 4, flexGrow: 1 }}>
          <Outlet />
        </Container>
      </Box>
    </Box>
  );
}
