import { Card } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';


export default function DataTable({ rows, columns, loading = false, pageSize = 8 }) {
  return (
    <Card sx={{ p: 1 }}>
      <DataGrid
        rows={rows}
        columns={columns}
        loading={loading}
        autoHeight
        disableRowSelectionOnClick
        pageSizeOptions={[5, 8, 10, 25]}
        initialState={{ pagination: { paginationModel: { pageSize, page: 0 } } }}
        sx={{
          border: 'none',
          '& .MuiDataGrid-columnHeaders': { fontWeight: 700 },
          '& .MuiDataGrid-cell:focus, & .MuiDataGrid-cell:focus-within': { outline: 'none' },
          '& .MuiDataGrid-row:hover': { backgroundColor: 'action.hover' },
        }}
      />
    </Card>
  );
}
