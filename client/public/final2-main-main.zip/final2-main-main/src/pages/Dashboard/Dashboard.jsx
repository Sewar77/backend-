import { useMemo, useState } from 'react';
import {
  Box, Grid, Card, CardContent, Typography, Button, Stack, Chip, Rating, Avatar,
  List, ListItem, ListItemText, Divider,
} from '@mui/material';
import GridViewRounded from '@mui/icons-material/GridViewRounded';
import FavoriteRounded from '@mui/icons-material/FavoriteRounded';
import RateReviewRounded from '@mui/icons-material/RateReviewRounded';
import CategoryRounded from '@mui/icons-material/CategoryRounded';
import SendRounded from '@mui/icons-material/SendRounded';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { useNotification } from '../../context/NotificationContext';
import StatCard from '../../components/DashboardCards/StatCard';
import BarChartCard from '../../components/Charts/BarChartCard';
import PieChartCard from '../../components/Charts/PieChartCard';
import PageHeader from '../../components/PageHeader';
import MessageForm from '../../components/Forms/MessageForm';
import { gradients } from '../../theme/theme';

export default function Dashboard() {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const { services, categories, reviews, favorites, addMessage } = useData();
  const { notify } = useNotification();
  const [composeOpen, setComposeOpen] = useState(false);

  const myFavorites = favorites[currentUser.id] ?? [];
  const approvedReviews = useMemo(() => reviews.filter((r) => r.status === 'approved'), [reviews]);

  // Services per category for the bar chart.
  const byCategory = useMemo(
    () =>
      categories.map((c) => ({
        name: c.name.split(' ')[0],
        value: services.filter((s) => s.categoryId === c.id).length,
      })),
    [categories, services],
  );

  // Service status split for the pie chart.
  const byStatus = useMemo(() => {
    const counts = services.reduce((acc, s) => ({ ...acc, [s.status]: (acc[s.status] ?? 0) + 1 }), {});
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [services]);

  const stats = [
    { title: 'Available services', value: services.length, icon: <GridViewRounded />, gradient: gradients.primary, subtitle: 'Across all categories' },
    { title: 'My favorites', value: myFavorites.length, icon: <FavoriteRounded />, gradient: gradients.accent, subtitle: 'Saved services' },
    { title: 'Categories', value: categories.length, icon: <CategoryRounded />, gradient: gradients.success, subtitle: 'To explore' },
    { title: 'Approved reviews', value: approvedReviews.length, icon: <RateReviewRounded />, gradient: gradients.primary, subtitle: 'Community feedback' },
  ];

  const handleSend = (data) => {
    addMessage({ ...data, fromName: currentUser.name, fromEmail: currentUser.email });
    setComposeOpen(false);
    notify('Message sent to the admin team.', 'success');
  };

  return (
    <Box>
      <PageHeader
        title="Your dashboard"
        subtitle="A quick overview of your workspace."
        action={<Button variant="contained" startIcon={<SendRounded />} onClick={() => setComposeOpen(true)}>Message admin</Button>}
      />

      <Grid container spacing={3} sx={{ mb: 1 }}>
        {stats.map((s) => (
          <Grid key={s.title} size={{ xs: 12, sm: 6, md: 3 }}>
            <StatCard {...s} />
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={3} sx={{ mt: 0 }}>
        <Grid size={{ xs: 12, md: 7 }}>
          <BarChartCard title="Services by category" subtitle="How the catalog is distributed" data={byCategory} />
        </Grid>
        <Grid size={{ xs: 12, md: 5 }}>
          <PieChartCard title="Service status" subtitle="Active vs. draft vs. archived" data={byStatus} />
        </Grid>
      </Grid>

      <Grid container spacing={3} sx={{ mt: 0 }}>
        <Grid size={{ xs: 12, md: 7 }}>
          <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>Approved reviews</Typography>
          <Card>
            <List disablePadding>
              {approvedReviews.slice(0, 6).map((r, i) => (
                <Box key={r.id}>
                  <ListItem>
                    <ListItemText
                      primary={
                        <Stack direction="row" spacing={1} alignItems="center">
                          <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>{r.author}</Typography>
                          <Rating value={r.rating} size="small" readOnly />
                        </Stack>
                      }
                      secondary={r.comment}
                    />
                  </ListItem>
                  {i < 5 && <Divider component="li" />}
                </Box>
              ))}
            </List>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 5 }}>
          <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>Quick actions</Typography>
          <Card>
            <CardContent>
              <Stack spacing={2}>
                <Button fullWidth variant="outlined" startIcon={<GridViewRounded />} onClick={() => navigate('/app/services')}>Browse all services</Button>
                <Button fullWidth variant="outlined" startIcon={<FavoriteRounded />} onClick={() => navigate('/app/favorites')}>Manage favorites</Button>
                <Button fullWidth variant="outlined" startIcon={<RateReviewRounded />} onClick={() => navigate('/app/profile')}>Edit profile</Button>
              </Stack>
              <Divider sx={{ my: 2 }} />
              <Stack direction="row" spacing={1.5} alignItems="center">
                <Avatar src={currentUser.avatar} />
                <Box>
                  <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>{currentUser.name}</Typography>
                  <Chip size="small" label="Member" color="primary" sx={{ mt: 0.5 }} />
                </Box>
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <MessageForm key={composeOpen ? 'compose' : 'closed'} open={composeOpen} mode="self" onClose={() => setComposeOpen(false)} onSubmit={handleSend} />
    </Box>
  );
}
