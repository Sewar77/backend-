import { useState } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button, Grid,
  TextField, MenuItem,
} from '@mui/material';

const EMPTY = { name: '', email: '', password: '123456', role: 'user', status: 'active' };
const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


export default function UserForm({ open, initialData, onSubmit, onClose }) {
  const isEdit = Boolean(initialData);
  const [form, setForm] = useState(() => (initialData ? { ...EMPTY, ...initialData } : EMPTY));
  const [errors, setErrors] = useState({});

  const handle = (field) => (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = 'Name is required';
    if (!emailRe.test(form.email)) next.email = 'Valid email is required';
    if (!isEdit && !form.password) next.password = 'Password is required';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const submit = () => {
    if (!validate()) return;
    onSubmit({ ...form });
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth slotProps={{ paper: { sx: { borderRadius: 3 } } }}>
      <DialogTitle>{isEdit ? 'Edit user' : 'Add user'}</DialogTitle>
      <DialogContent dividers>
        <Grid container spacing={2} sx={{ mt: 0 }}>
          <Grid size={12}>
            <TextField fullWidth label="Full name" value={form.name} onChange={handle('name')} error={!!errors.name} helperText={errors.name} />
          </Grid>
          <Grid size={12}>
            <TextField fullWidth label="Email" value={form.email} onChange={handle('email')} error={!!errors.email} helperText={errors.email} />
          </Grid>
          {!isEdit && (
            <Grid size={12}>
              <TextField fullWidth label="Password" value={form.password} onChange={handle('password')} error={!!errors.password} helperText={errors.password} />
            </Grid>
          )}
          <Grid size={{ xs: 6 }}>
            <TextField select fullWidth label="Role" value={form.role} onChange={handle('role')}>
              <MenuItem value="user">User</MenuItem>
              <MenuItem value="admin">Admin</MenuItem>
            </TextField>
          </Grid>
          <Grid size={{ xs: 6 }}>
            <TextField select fullWidth label="Status" value={form.status} onChange={handle('status')}>
              <MenuItem value="active">Active</MenuItem>
              <MenuItem value="inactive">Inactive</MenuItem>
            </TextField>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions sx={{ p: 2.5 }}>
        <Button color="inherit" onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={submit}>{isEdit ? 'Save changes' : 'Add user'}</Button>
      </DialogActions>
    </Dialog>
  );
}
