import { Box, Typography } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import { gradients } from '../theme/theme';


export default function Logo({ to = '/', size = 36, showText = true }) {
  return (
    <Box
      component={RouterLink}
      to={to}
      sx={{ display: 'flex', alignItems: 'center', gap: 1.2, textDecoration: 'none' }}
    >
      <Box
        sx={{
          width: size,
          height: size,
          borderRadius: 2,
          background: gradients.brand,
          display: 'grid',
          placeItems: 'center',
          color: '#fff',
          fontWeight: 900,
          fontSize: size * 0.5,
          boxShadow: '0 8px 24px rgba(99,102,241,0.45)',
          flexShrink: 0,
        }}
      >
        S
      </Box>
      {showText && (
        <Typography
          variant="h6"
          sx={{
            fontWeight: 800,
            letterSpacing: '-0.02em',
            background: gradients.brand,
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            whiteSpace: 'nowrap',
          }}
        >
          ServiceHub&nbsp;Pro
        </Typography>
      )}
    </Box>
  );
}
