const comments = [
  'Absolutely exceeded my expectations. Fast and professional!',
  'Great communication throughout the whole project.',
  'Solid work, would happily hire again.',
  'The delivery was a bit slow but the quality was worth it.',
  'Best decision we made this quarter.',
  'Polished result and very responsive team.',
  'Helped us ship weeks ahead of schedule.',
  'Clear pricing and no surprises.',
  'Good value for the price.',
  'Highly recommend to any startup.',
];

const statuses = ['approved', 'approved', 'approved', 'pending', 'rejected'];

export const reviews = Array.from({ length: 20 }, (_, i) => ({
  id: `rev-${i + 1}`,
  serviceId: `srv-${(i % 30) + 1}`,
  userId: `usr-${(i % 20) + 1}`,
  author: ['Alex Carter', 'Jordan Nguyen', 'Taylor Patel', 'Morgan Garcia', 'Casey Kim'][i % 5],
  rating: 3 + (i % 3),
  comment: comments[i % comments.length],
  status: statuses[i % statuses.length],
  createdAt: `2025-${String((i % 12) + 1).padStart(2, '0')}-${String((i % 27) + 1).padStart(2, '0')}`,
}));

export default reviews;
