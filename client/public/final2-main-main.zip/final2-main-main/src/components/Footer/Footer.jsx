import { Box, Container, Grid, Stack, Typography, Link, IconButton, Divider } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import GitHub from '@mui/icons-material/GitHub';
import Twitter from '@mui/icons-material/Twitter';
import LinkedIn from '@mui/icons-material/LinkedIn';
import Logo from '../Logo';

const columns = [
  { title: 'Product', links: [['Services', '/services'], ['About', '/about'], ['Contact', '/contact']] },
  { title: 'Account', links: [['Login', '/login'], ['Register', '/register']] },
  { title: 'Company', links: [['About us', '/about'], ['Contact', '/contact']] },
];

export default function Footer() {
  return (
    <Box
      component="footer"
      sx={{
        mt: 'auto',
        borderTop: (t) => `1px solid ${t.palette.divider}`,
        bgcolor: (t) => (t.palette.mode === 'dark' ? 'rgba(15,23,42,0.6)' : 'rgba(255,255,255,0.6)'),
        backdropFilter: 'blur(8px)',
      }}
    >
      <Container maxWidth="lg" sx={{ py: 6 }}>
        <Grid container spacing={4}>
          <Grid size={{ xs: 12, md: 4 }}>
            <Logo />
            <Typography variant="body2" color="text.secondary" sx={{ mt: 2, maxWidth: 320 }}>
              The modern platform to discover, manage and grow with the best digital services —
              all in one beautifully designed hub.
            </Typography>
            <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
              <IconButton size="small" aria-label="GitHub"><GitHub fontSize="small" /></IconButton>
              <IconButton size="small" aria-label="Twitter"><Twitter fontSize="small" /></IconButton>
              <IconButton size="small" aria-label="LinkedIn"><LinkedIn fontSize="small" /></IconButton>
            </Stack>
          </Grid>
          {columns.map((col) => (
            <Grid key={col.title} size={{ xs: 6, md: 2 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1.5 }}>{col.title}</Typography>
              <Stack spacing={1}>
                {col.links.map(([label, to]) => (
                  <Link
                    key={label}
                    component={RouterLink}
                    to={to}
                    underline="hover"
                    color="text.secondary"
                    variant="body2"
                  >
                    {label}
                  </Link>
                ))}
              </Stack>
            </Grid>
          ))}
        </Grid>
        <Divider sx={{ my: 4 }} />
        <Stack
          direction={{ xs: 'column', sm: 'row' }}
          justifyContent="space-between"
          alignItems="center"
          spacing={1}
        >
          <Typography variant="body2" color="text.secondary">
            © {new Date().getFullYear()} ServiceHub Pro. All rights reserved.
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Built with React, Vite & Material UI.
          </Typography>
        </Stack>
      </Container>
    </Box>
  );
}
