import { useMemo } from 'react';
import {
  Box, Grid, Card, CardContent, Typography, Button, Avatar, Stack, Chip,
  List, ListItem, ListItemAvatar, ListItemText, Divider,
} from '@mui/material';
import GridViewRounded from '@mui/icons-material/GridViewRounded';
import FavoriteRounded from '@mui/icons-material/FavoriteRounded';
import MailRounded from '@mui/icons-material/MailRounded';
import PersonRounded from '@mui/icons-material/PersonRounded';
import ArrowForwardRounded from '@mui/icons-material/ArrowForwardRounded';
import RateReviewRounded from '@mui/icons-material/RateReviewRounded';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import ServiceCard from '../../components/ServiceCard';
import { gradients } from '../../theme/theme';

const shortcuts = [
  { label: 'Browse services', icon: <GridViewRounded />, to: '/app/services', g: gradients.primary },
  { label: 'My favorites', icon: <FavoriteRounded />, to: '/app/favorites', g: gradients.accent },
  { label: 'Messages', icon: <MailRounded />, to: '/app/messages', g: gradients.success },
  { label: 'Edit profile', icon: <PersonRounded />, to: '/app/profile', g: gradients.primary },
];

export default function Home() {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const { services, categories, reviews, toggleFavorite, isFavorite } = useData();

  const categoryById = useMemo(() => Object.fromEntries(categories.map((c) => [c.id, c])), [categories]);
  const featured = useMemo(() => services.filter((s) => s.featured).slice(0, 3), [services]);
  const recentReviews = useMemo(
    () => reviews.filter((r) => r.status === 'approved').slice(0, 5),
    [reviews],
  );

  return (
    <Box>
      {/* Welcome banner */}
      <Card sx={{ position: 'relative', overflow: 'hidden', mb: 4, color: '#fff', background: gradients.brand }}>
        <Box sx={{ position: 'absolute', inset: 0, opacity: 0.25, background: 'radial-gradient(circle at 85% 20%, #fff, transparent 45%)' }} />
        <CardContent sx={{ position: 'relative', p: { xs: 3, md: 5 } }}>
          <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" alignItems={{ md: 'center' }} spacing={2}>
            <Box>
              <Chip label="Welcome back" sx={{ bgcolor: 'rgba(255,255,255,0.2)', color: '#fff', mb: 1.5, fontWeight: 600 }} />
              <Typography variant="h3" sx={{ fontWeight: 800 }}>Hi, {currentUser?.name?.split(' ')[0]} 👋</Typography>
              <Typography variant="h6" sx={{ fontWeight: 400, opacity: 0.9, mt: 1 }}>
                Here&apos;s what&apos;s happening in your workspace today.
              </Typography>
            </Box>
            <Button variant="contained" color="inherit" endIcon={<ArrowForwardRounded />} onClick={() => navigate('/app/services')} sx={{ color: 'primary.main', bgcolor: '#fff', '&:hover': { bgcolor: '#f1f5f9' } }}>
              Explore services
            </Button>
          </Stack>
        </CardContent>
      </Card>

      {/* Shortcuts */}
      <Grid container spacing={2} sx={{ mb: 4 }}>
        {shortcuts.map((s) => (
          <Grid key={s.label} size={{ xs: 6, md: 3 }}>
            <Card
              onClick={() => navigate(s.to)}
              sx={{ cursor: 'pointer', transition: 'transform .2s ease, box-shadow .2s ease', '&:hover': { transform: 'translateY(-4px)', boxShadow: '0 16px 36px rgba(2,6,23,0.24)' } }}
            >
              <CardContent>
                <Stack direction="row" spacing={1.5} alignItems="center">
                  <Avatar sx={{ background: s.g, boxShadow: 3 }}>{s.icon}</Avatar>
                  <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>{s.label}</Typography>
                </Stack>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={3}>
        {/* Featured services */}
        <Grid size={{ xs: 12, lg: 8 }}>
          <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
            <Typography variant="h5" sx={{ fontWeight: 700 }}>Featured services</Typography>
            <Button size="small" onClick={() => navigate('/app/services')} endIcon={<ArrowForwardRounded />}>View all</Button>
          </Stack>
          <Grid container spacing={3}>
            {featured.map((s) => (
              <Grid key={s.id} size={{ xs: 12, sm: 6, md: 4 }}>
                <ServiceCard
                  service={s}
                  category={categoryById[s.categoryId]}
                  favorite={isFavorite(currentUser.id, s.id)}
                  onToggleFavorite={(id) => toggleFavorite(currentUser.id, id)}
                  onView={() => navigate('/app/services')}
                />
              </Grid>
            ))}
          </Grid>
        </Grid>

        {/* Recent activity */}
        <Grid size={{ xs: 12, lg: 4 }}>
          <Typography variant="h5" sx={{ fontWeight: 700, mb: 2 }}>Recent activity</Typography>
          <Card>
            <List disablePadding>
              {recentReviews.map((r, i) => (
                <Box key={r.id}>
                  <ListItem alignItems="flex-start">
                    <ListItemAvatar>
                      <Avatar sx={{ background: gradients.accent }}><RateReviewRounded /></Avatar>
                    </ListItemAvatar>
                    <ListItemText
                      primary={<Typography variant="subtitle2" sx={{ fontWeight: 700 }}>{r.author}</Typography>}
                      secondary={
                        <>
                          <Typography component="span" variant="body2" color="text.secondary">{r.comment}</Typography>
                          <br />
                          <Typography component="span" variant="caption" color="text.secondary">{r.createdAt}</Typography>
                        </>
                      }
                    />
                  </ListItem>
                  {i < recentReviews.length - 1 && <Divider component="li" />}
                </Box>
              ))}
            </List>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
