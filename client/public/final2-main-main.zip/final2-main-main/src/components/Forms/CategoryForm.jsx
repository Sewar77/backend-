import { useState } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button, Grid,
  TextField, MenuItem, Box,
} from '@mui/material';

const ICON_NAMES = [
  'Code', 'PhoneIphone', 'Brush', 'Cloud', 'Insights',
  'Campaign', 'Security', 'Handshake', 'Article', 'SupportAgent',
];

const EMPTY = { name: '', description: '', color: '#6366F1', icon: 'Code' };


export default function CategoryForm({ open, initialData, onSubmit, onClose }) {
  const isEdit = Boolean(initialData);
  const [form, setForm] = useState(() => (initialData ? { ...EMPTY, ...initialData } : EMPTY));
  const [errors, setErrors] = useState({});

  const handle = (field) => (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = 'Name is required';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const submit = () => {
    if (!validate()) return;
    onSubmit({ ...form });
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth slotProps={{ paper: { sx: { borderRadius: 3 } } }}>
      <DialogTitle>{isEdit ? 'Edit category' : 'Create category'}</DialogTitle>
      <DialogContent dividers>
        <Grid container spacing={2} sx={{ mt: 0 }}>
          <Grid size={12}>
            <TextField fullWidth label="Category name" value={form.name} onChange={handle('name')} error={!!errors.name} helperText={errors.name} />
          </Grid>
          <Grid size={12}>
            <TextField fullWidth multiline minRows={2} label="Description" value={form.description} onChange={handle('description')} />
          </Grid>
          <Grid size={{ xs: 6 }}>
            <TextField select fullWidth label="Icon" value={form.icon} onChange={handle('icon')}>
              {ICON_NAMES.map((n) => (
                <MenuItem key={n} value={n}>{n}</MenuItem>
              ))}
            </TextField>
          </Grid>
          <Grid size={{ xs: 6 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <TextField
                fullWidth
                type="color"
                label="Color"
                value={form.color}
                onChange={handle('color')}
                InputLabelProps={{ shrink: true }}
              />
            </Box>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions sx={{ p: 2.5 }}>
        <Button color="inherit" onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={submit}>{isEdit ? 'Save changes' : 'Create'}</Button>
      </DialogActions>
    </Dialog>
  );
}
