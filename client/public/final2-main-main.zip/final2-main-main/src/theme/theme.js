import { createTheme } from '@mui/material/styles';


export const brand = {
  primary: '#6366F1',
  secondary: '#8B5CF6',
  accent: '#06B6D4',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  darkBg: '#0F172A',
  darkSurface: '#1E293B',
};

export const gradients = {
  primary: `linear-gradient(135deg, ${brand.primary} 0%, ${brand.secondary} 100%)`,
  brand: `linear-gradient(135deg, ${brand.primary} 0%, ${brand.secondary} 50%, ${brand.accent} 100%)`,
  accent: `linear-gradient(135deg, ${brand.secondary} 0%, ${brand.accent} 100%)`,
  success: `linear-gradient(135deg, ${brand.success} 0%, ${brand.accent} 100%)`,
  darkPage:
    'radial-gradient(1200px 600px at 10% -10%, rgba(99,102,241,0.25), transparent 60%),' +
    'radial-gradient(1000px 500px at 100% 0%, rgba(6,182,212,0.18), transparent 55%),' +
    'linear-gradient(180deg, #0B1120 0%, #0F172A 100%)',
  lightPage:
    'radial-gradient(1200px 600px at 10% -10%, rgba(99,102,241,0.18), transparent 60%),' +
    'radial-gradient(1000px 500px at 100% 0%, rgba(6,182,212,0.14), transparent 55%),' +
    'linear-gradient(180deg, #F8FAFC 0%, #EEF2FF 100%)',
};


export const buildTheme = (mode) => {
  const isDark = mode === 'dark';

  return createTheme({
    palette: {
      mode,
      primary: { main: brand.primary, light: '#818CF8', dark: '#4F46E5', contrastText: '#fff' },
      secondary: { main: brand.secondary, light: '#A78BFA', dark: '#7C3AED', contrastText: '#fff' },
      info: { main: brand.accent, contrastText: '#fff' },
      success: { main: brand.success, contrastText: '#fff' },
      warning: { main: brand.warning },
      error: { main: brand.error },
      background: {
        default: isDark ? brand.darkBg : '#F8FAFC',
        paper: isDark ? brand.darkSurface : '#FFFFFF',
      },
      text: {
        primary: isDark ? '#E2E8F0' : '#0F172A',
        secondary: isDark ? '#94A3B8' : '#475569',
      },
      divider: isDark ? 'rgba(148,163,184,0.16)' : 'rgba(15,23,42,0.10)',
    },
    shape: { borderRadius: 16 },
    typography: {
      fontFamily: '"Inter", "Plus Jakarta Sans", system-ui, sans-serif',
      h1: { fontFamily: '"Plus Jakarta Sans", sans-serif', fontWeight: 800, letterSpacing: '-0.02em' },
      h2: { fontFamily: '"Plus Jakarta Sans", sans-serif', fontWeight: 800, letterSpacing: '-0.02em' },
      h3: { fontFamily: '"Plus Jakarta Sans", sans-serif', fontWeight: 700, letterSpacing: '-0.01em' },
      h4: { fontFamily: '"Plus Jakarta Sans", sans-serif', fontWeight: 700 },
      h5: { fontWeight: 700 },
      h6: { fontWeight: 700 },
      button: { fontWeight: 600, textTransform: 'none' },
      subtitle1: { fontWeight: 600 },
    },
    components: {
      MuiCssBaseline: {
        styleOverrides: {
          body: {
            backgroundAttachment: 'fixed',
            scrollbarColor: isDark ? '#334155 transparent' : '#CBD5E1 transparent',
          },
          '*::-webkit-scrollbar': { width: 10, height: 10 },
          '*::-webkit-scrollbar-thumb': {
            backgroundColor: isDark ? '#334155' : '#CBD5E1',
            borderRadius: 8,
          },
        },
      },
      MuiButton: {
        defaultProps: { disableElevation: true },
        styleOverrides: {
          root: { borderRadius: 12, paddingInline: 18, paddingBlock: 9 },
          containedPrimary: {
            background: gradients.primary,
            '&:hover': { background: gradients.brand },
          },
        },
      },
      MuiCard: {
        styleOverrides: {
          root: {
            borderRadius: 20,
            border: `1px solid ${isDark ? 'rgba(148,163,184,0.14)' : 'rgba(15,23,42,0.08)'}`,
            backgroundImage: 'none',
          },
        },
      },
      MuiPaper: { styleOverrides: { root: { backgroundImage: 'none' } } },
      MuiChip: { styleOverrides: { root: { fontWeight: 600 } } },
      MuiTextField: { defaultProps: { variant: 'outlined', size: 'small' } },
      MuiAppBar: { styleOverrides: { root: { backgroundImage: 'none' } } },
    },
  });
};

export default buildTheme;
