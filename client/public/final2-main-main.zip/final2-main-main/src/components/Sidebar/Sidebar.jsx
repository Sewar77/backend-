import {
  Drawer, Box, List, ListItem, ListItemButton, ListItemIcon,
  ListItemText, Toolbar, Typography, Chip, Divider,
} from '@mui/material';
import { NavLink } from 'react-router-dom';
import Logo from '../Logo';
import { useAuth } from '../../context/AuthContext';

export const SIDEBAR_WIDTH = 264;


export default function Sidebar({ items, mobileOpen, onClose, label = 'Workspace' }) {
  const { currentUser, isAdmin } = useAuth();

  const content = (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <Toolbar sx={{ px: 2 }}>
        <Logo />
      </Toolbar>
      <Divider />
      <Box sx={{ px: 2, py: 1.5 }}>
        <Typography variant="overline" color="text.secondary">{label}</Typography>
      </Box>
      <List sx={{ px: 1.5, flexGrow: 1 }}>
        {items.map((item) => (
          <ListItem key={item.to} disablePadding sx={{ mb: 0.5 }}>
            <ListItemButton
              component={NavLink}
              to={item.to}
              end={item.end}
              onClick={onClose}
              sx={{
                borderRadius: 2,
                '&.active': {
                  color: 'primary.contrastText',
                  background: (t) =>
                    `linear-gradient(135deg, ${t.palette.primary.main}, ${t.palette.secondary.main})`,
                  boxShadow: '0 8px 20px rgba(99,102,241,0.35)',
                  '& .MuiListItemIcon-root': { color: 'inherit' },
                },
              }}
            >
              <ListItemIcon sx={{ minWidth: 40 }}>{item.icon}</ListItemIcon>
              <ListItemText primary={item.label} primaryTypographyProps={{ fontWeight: 600 }} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
      <Divider />
      <Box sx={{ p: 2, display: 'flex', alignItems: 'center', gap: 1.2 }}>
        <Box>
          <Typography variant="body2" noWrap sx={{ fontWeight: 700, maxWidth: 160 }}>
            {currentUser?.name}
          </Typography>
          <Chip
            size="small"
            label={isAdmin ? 'Admin' : 'Member'}
            color={isAdmin ? 'secondary' : 'primary'}
            sx={{ mt: 0.5 }}
          />
        </Box>
      </Box>
    </Box>
  );

  const paperSx = {
    width: SIDEBAR_WIDTH,
    boxSizing: 'border-box',
    border: 'none',
    bgcolor: (t) => (t.palette.mode === 'dark' ? 'rgba(15,23,42,0.85)' : 'rgba(255,255,255,0.9)'),
    backdropFilter: 'blur(12px)',
    borderRight: (t) => `1px solid ${t.palette.divider}`,
  };

  return (
    <Box component="nav" sx={{ width: { lg: SIDEBAR_WIDTH }, flexShrink: { lg: 0 } }}>
      {/* Mobile temporary drawer */}
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={onClose}
        ModalProps={{ keepMounted: true }}
        sx={{ display: { xs: 'block', lg: 'none' }, '& .MuiDrawer-paper': paperSx }}
      >
        {content}
      </Drawer>
      {/* Desktop permanent drawer */}
      <Drawer
        variant="permanent"
        open
        sx={{ display: { xs: 'none', lg: 'block' }, '& .MuiDrawer-paper': paperSx }}
      >
        {content}
      </Drawer>
    </Box>
  );
}
