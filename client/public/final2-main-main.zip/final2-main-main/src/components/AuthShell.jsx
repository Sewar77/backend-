import { Box, Grid, Stack, Typography, Chip } from '@mui/material';
import CheckCircleRounded from '@mui/icons-material/CheckCircleRounded';
import Logo from './Logo';
import ThemeToggle from './ThemeToggle';
import { gradients } from '../theme/theme';

const perks = [
  'Browse 30+ premium services',
  'Real-time analytics dashboard',
  'Role-based admin controls',
  'Dark & light mode included',
];


export default function AuthShell({ children }) {
  return (
    <Grid container sx={{ minHeight: '100vh' }}>
      {/* Brand panel */}
      <Grid
        size={{ xs: 12, md: 6 }}
        sx={{
          display: { xs: 'none', md: 'flex' },
          flexDirection: 'column',
          justifyContent: 'space-between',
          p: 6,
          color: '#fff',
          position: 'relative',
          overflow: 'hidden',
          background: gradients.brand,
        }}
      >
        <Box sx={{ position: 'absolute', top: -120, right: -120, width: 360, height: 360, borderRadius: '50%', background: 'rgba(255,255,255,0.18)', filter: 'blur(40px)' }} />
        <Logo />
        <Box sx={{ position: 'relative' }}>
          <Typography variant="h3" sx={{ fontWeight: 800, mb: 2 }}>
            The modern home for your digital services.
          </Typography>
          <Typography variant="h6" sx={{ fontWeight: 400, opacity: 0.9, mb: 4 }}>
            Discover, manage and grow — all from one beautiful workspace.
          </Typography>
          <Stack spacing={1.5}>
            {perks.map((p) => (
              <Stack key={p} direction="row" spacing={1.2} alignItems="center">
                <CheckCircleRounded />
                <Typography variant="body1">{p}</Typography>
              </Stack>
            ))}
          </Stack>
        </Box>
        <Typography variant="body2" sx={{ opacity: 0.8 }}>© {new Date().getFullYear()} ServiceHub Pro</Typography>
      </Grid>

      {/* Form panel */}
      <Grid
        size={{ xs: 12, md: 6 }}
        sx={{
          display: 'flex',
          flexDirection: 'column',
          background: (t) => (t.palette.mode === 'dark' ? gradients.darkPage : gradients.lightPage),
        }}
      >
        <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ p: 3 }}>
          <Box sx={{ display: { md: 'none' } }}><Logo /></Box>
          <Chip label="Demo ready" color="success" size="small" variant="outlined" sx={{ display: { xs: 'none', md: 'inline-flex' } }} />
          <Box sx={{ flexGrow: 1 }} />
          <ThemeToggle />
        </Stack>
        <Box sx={{ flexGrow: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', px: { xs: 3, sm: 6 }, pb: 6 }}>
          <Box sx={{ width: '100%', maxWidth: 420 }}>{children}</Box>
        </Box>
      </Grid>
    </Grid>
  );
}
