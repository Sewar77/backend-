import { useTheme } from '@mui/material/styles';
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
} from 'recharts';
import ChartCard from './ChartCard';
import { brand } from '../../theme/theme';


export default function LineChartCard({ title, subtitle, data }) {
  const theme = useTheme();
  return (
    <ChartCard title={title} subtitle={subtitle}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
          <defs>
            <linearGradient id="activityFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={brand.primary} stopOpacity={0.5} />
              <stop offset="100%" stopColor={brand.primary} stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke={theme.palette.divider} vertical={false} />
          <XAxis dataKey="name" tick={{ fontSize: 12, fill: theme.palette.text.secondary }} />
          <YAxis allowDecimals={false} tick={{ fontSize: 12, fill: theme.palette.text.secondary }} />
          <Tooltip
            contentStyle={{
              background: theme.palette.background.paper,
              border: `1px solid ${theme.palette.divider}`,
              borderRadius: 12,
            }}
          />
          <Area
            type="monotone"
            dataKey="value"
            stroke={brand.primary}
            strokeWidth={3}
            fill="url(#activityFill)"
            dot={{ r: 3, fill: brand.secondary }}
            activeDot={{ r: 5 }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}
