import { createContext, useCallback, useContext, useMemo } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { useData } from './DataContext';

const AuthContext = createContext(null);


export function AuthProvider({ children }) {
  const { users, addUser, updateUser } = useData();
  const [currentUser, setCurrentUser] = useLocalStorage('servicehub_current_user', null);

  const login = useCallback(
    (email, password) => {
      const found = users.find(
        (u) => u.email.toLowerCase() === String(email).toLowerCase().trim() && u.password === password,
      );
      if (!found) return { ok: false, error: 'Invalid email or password.' };
      if (found.status === 'inactive') {
        return { ok: false, error: 'This account is inactive. Contact an administrator.' };
      }
      const { password: _pw, ...safe } = found;
      void _pw;
      setCurrentUser(safe);
      return { ok: true, user: safe };
    },
    [users, setCurrentUser],
  );

  const register = useCallback(
    ({ name, email, password }) => {
      const exists = users.some(
        (u) => u.email.toLowerCase() === String(email).toLowerCase().trim(),
      );
      if (exists) return { ok: false, error: 'An account with this email already exists.' };

      const safeEmail = email.toLowerCase().trim();
      addUser({ name: name.trim(), email: safeEmail, password, role: 'user', status: 'active', bio: 'New member of the ServiceHub Pro community.' });
      setCurrentUser({
        id: `usr-pending-${Date.now()}`,
        name: name.trim(),
        email: safeEmail,
        role: 'user',
        status: 'active',
        avatar: `https://i.pravatar.cc/150?u=${encodeURIComponent(safeEmail)}`,
        joinedAt: new Date().toISOString().slice(0, 10),
        bio: 'New member of the ServiceHub Pro community.',
      });
      return { ok: true };
    },
    [users, addUser, setCurrentUser],
  );

  const logout = useCallback(() => setCurrentUser(null), [setCurrentUser]);

  const updateProfile = useCallback(
    (updates) => {
      setCurrentUser((prev) => (prev ? { ...prev, ...updates } : prev));
      if (currentUser?.id) updateUser(currentUser.id, updates);
    },
    [currentUser, updateUser, setCurrentUser],
  );

  const value = useMemo(
    () => ({
      currentUser,
      role: currentUser?.role ?? null,
      isAuthenticated: Boolean(currentUser),
      isAdmin: currentUser?.role === 'admin',
      login,
      logout,
      register,
      updateProfile,
    }),
    [currentUser, login, logout, register, updateProfile],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}

export default AuthContext;
