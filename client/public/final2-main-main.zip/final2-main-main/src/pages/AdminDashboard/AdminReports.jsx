import { useMemo } from 'react';
import {
  Box, Grid, Card, CardContent, Typography, Chip, Stack, Avatar, Divider,
  List, ListItem, ListItemText, Rating,
} from '@mui/material';
import GroupRounded from '@mui/icons-material/GroupRounded';
import GridViewRounded from '@mui/icons-material/GridViewRounded';
import StarRounded from '@mui/icons-material/StarRounded';
import PaidRounded from '@mui/icons-material/PaidRounded';
import { useData } from '../../context/DataContext';
import StatCard from '../../components/DashboardCards/StatCard';
import BarChartCard from '../../components/Charts/BarChartCard';
import PieChartCard from '../../components/Charts/PieChartCard';
import LineChartCard from '../../components/Charts/LineChartCard';
import PageHeader from '../../components/PageHeader';
import { gradients } from '../../theme/theme';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export default function AdminReports() {
  const { users, services, categories, reviews } = useData();

  const avgRating = useMemo(
    () => (services.reduce((sum, s) => sum + s.rating, 0) / (services.length || 1)).toFixed(2),
    [services],
  );
  const totalValue = useMemo(() => services.reduce((sum, s) => sum + s.price, 0), [services]);

  const usersByStatus = useMemo(() => {
    const counts = users.reduce((acc, u) => ({ ...acc, [u.status]: (acc[u.status] ?? 0) + 1 }), {});
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [users]);

  const priceByCategory = useMemo(
    () => categories.map((c) => ({
      name: c.name.split(' ')[0],
      value: services.filter((s) => s.categoryId === c.id).reduce((sum, s) => sum + s.price, 0),
    })),
    [categories, services],
  );

  const reviewsByMonth = useMemo(() => {
    const counts = Array(12).fill(0);
    reviews.forEach((r) => {
      const m = Number((r.createdAt ?? '2025-01').slice(5, 7)) - 1;
      if (m >= 0 && m < 12) counts[m] += 1;
    });
    return MONTHS.map((name, i) => ({ name, value: counts[i] }));
  }, [reviews]);

  const topServices = useMemo(
    () => [...services].sort((a, b) => b.rating - a.rating).slice(0, 6),
    [services],
  );

  const stats = [
    { title: 'Catalog value', value: `$${totalValue.toLocaleString()}`, icon: <PaidRounded />, gradient: gradients.primary, subtitle: 'Sum of all prices' },
    { title: 'Avg. rating', value: avgRating, icon: <StarRounded />, gradient: gradients.accent, subtitle: 'Across all services' },
    { title: 'Active users', value: users.filter((u) => u.status === 'active').length, icon: <GroupRounded />, gradient: gradients.success, subtitle: `of ${users.length} total` },
    { title: 'Services', value: services.length, icon: <GridViewRounded />, gradient: gradients.primary, subtitle: 'Published & draft' },
  ];

  return (
    <Box>
      <PageHeader title="Reports" subtitle="Deeper insights into your platform performance." />

      <Grid container spacing={3}>
        {stats.map((s) => (
          <Grid key={s.title} size={{ xs: 12, sm: 6, md: 3 }}>
            <StatCard {...s} />
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={3} sx={{ mt: 0 }}>
        <Grid size={{ xs: 12, md: 8 }}>
          <BarChartCard title="Catalog value by category" subtitle="Total price ($) per category" data={priceByCategory} />
        </Grid>
        <Grid size={{ xs: 12, md: 4 }}>
          <PieChartCard title="Users by status" subtitle="Active vs. inactive" data={usersByStatus} />
        </Grid>
      </Grid>

      <Grid container spacing={3} sx={{ mt: 0 }}>
        <Grid size={{ xs: 12, md: 8 }}>
          <LineChartCard title="Reviews over time" subtitle="Monthly review volume" data={reviewsByMonth} />
        </Grid>
        <Grid size={{ xs: 12, md: 4 }}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" sx={{ fontWeight: 700, mb: 1 }}>Top rated services</Typography>
              <List dense disablePadding>
                {topServices.map((s, i) => (
                  <Box key={s.id}>
                    <ListItem disableGutters secondaryAction={<Chip size="small" label={`$${s.price}`} />}>
                      <Avatar sx={{ width: 30, height: 30, mr: 1.5, background: gradients.primary, fontSize: 14 }}>{i + 1}</Avatar>
                      <ListItemText
                        primary={s.name}
                        secondary={<Stack direction="row" spacing={0.5} alignItems="center"><Rating value={s.rating} precision={0.1} size="small" readOnly emptyIcon={<StarRounded sx={{ opacity: 0.25, fontSize: 14 }} />} /><Typography variant="caption" color="text.secondary">{s.rating}</Typography></Stack>}
                        primaryTypographyProps={{ fontWeight: 600, variant: 'body2', noWrap: true }}
                      />
                    </ListItem>
                    {i < topServices.length - 1 && <Divider component="li" />}
                  </Box>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
