const firstNames = [
  'Alex', 'Jordan', 'Taylor', 'Morgan', 'Casey', 'Riley', 'Jamie', 'Avery',
  'Quinn', 'Drew', 'Sage', 'Reese', 'Skyler', 'Emerson', 'Hayden', 'Rowan',
  'Parker', 'Logan', 'Charlie', 'Finley',
];
const lastNames = [
  'Carter', 'Nguyen', 'Patel', 'Garcia', 'Kim', 'Hughes', 'Lopez', 'Walsh',
  'Brooks', 'Reed', 'Foster', 'Bennett', 'Sanders', 'Murphy', 'Coleman', 'Ross',
  'Diaz', 'Perry', 'Long', 'Ward',
];

const baseUsers = firstNames.map((first, i) => {
  const last = lastNames[i];
  const name = `${first} ${last}`;
  return {
    id: `usr-${i + 1}`,
    name,
    email: `${first}.${last}`.toLowerCase() + '@servicehub.io',
    password: '123456',
    role: 'user',
    status: i % 6 === 0 ? 'inactive' : 'active',
    avatar: `https://i.pravatar.cc/150?img=${(i % 70) + 1}`,
    joinedAt: `2025-${String((i % 12) + 1).padStart(2, '0')}-${String((i % 27) + 1).padStart(2, '0')}`,
    bio: `${first} is a member of the ServiceHub Pro community.`,
  };
});

// Seed the two well-known demo accounts.
export const users = [
  {
    id: 'usr-admin',
    name: 'Admin User',
    email: 'admin@test.com',
    password: '123456',
    role: 'admin',
    status: 'active',
    avatar: 'https://i.pravatar.cc/150?img=12',
    joinedAt: '2025-01-01',
    bio: 'Platform administrator for ServiceHub Pro.',
  },
  {
    id: 'usr-demo',
    name: 'Demo User',
    email: 'user@test.com',
    password: '123456',
    role: 'user',
    status: 'active',
    avatar: 'https://i.pravatar.cc/150?img=5',
    joinedAt: '2025-01-15',
    bio: 'Curious explorer browsing the best services.',
  },
  ...baseUsers,
];

export default users;
