import { useMemo, useState } from 'react';
import {
  Box, Grid, Card, CardContent, Typography, Button, Chip, Stack, Avatar,
  IconButton, Tooltip,
} from '@mui/material';
import AddRounded from '@mui/icons-material/AddRounded';
import MailRounded from '@mui/icons-material/MailRounded';
import DeleteRounded from '@mui/icons-material/DeleteRounded';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { useNotification } from '../../context/NotificationContext';
import PageHeader from '../../components/PageHeader';
import MessageForm from '../../components/Forms/MessageForm';
import ConfirmDialog from '../../components/Modals/ConfirmDialog';
import { gradients } from '../../theme/theme';

const statusColor = { unread: 'warning', read: 'info', replied: 'success' };

export default function Messages() {
  const { currentUser } = useAuth();
  const { messages, addMessage, deleteMessage } = useData();
  const { notify } = useNotification();
  const [composeOpen, setComposeOpen] = useState(false);
  const [toDelete, setToDelete] = useState(null);

  const myMessages = useMemo(
    () => messages.filter((m) => m.fromEmail?.toLowerCase() === currentUser.email.toLowerCase()),
    [messages, currentUser.email],
  );

  const handleSend = (data) => {
    addMessage({ ...data, fromName: currentUser.name, fromEmail: currentUser.email });
    setComposeOpen(false);
    notify('Message sent to the admin team.', 'success');
  };

  const confirmDelete = () => {
    deleteMessage(toDelete);
    setToDelete(null);
    notify('Message deleted.', 'info');
  };

  return (
    <Box>
      <PageHeader
        title="Messages"
        subtitle="Conversations with the ServiceHub Pro team."
        action={<Button variant="contained" startIcon={<AddRounded />} onClick={() => setComposeOpen(true)}>New message</Button>}
      />

      {myMessages.length === 0 ? (
        <Card sx={{ textAlign: 'center', py: 8 }}>
          <CardContent>
            <Avatar sx={{ background: gradients.primary, width: 72, height: 72, mx: 'auto', mb: 2 }}>
              <MailRounded sx={{ fontSize: 36 }} />
            </Avatar>
            <Typography variant="h6" sx={{ fontWeight: 700 }}>No messages yet</Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1, mb: 3 }}>
              Start a conversation with our team.
            </Typography>
            <Button variant="contained" startIcon={<AddRounded />} onClick={() => setComposeOpen(true)}>Send a message</Button>
          </CardContent>
        </Card>
      ) : (
        <Grid container spacing={2}>
          {myMessages.map((m) => (
            <Grid key={m.id} size={12}>
              <Card>
                <CardContent>
                  <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
                    <Box sx={{ minWidth: 0 }}>
                      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.5 }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>{m.subject}</Typography>
                        <Chip size="small" label={m.status} color={statusColor[m.status]} sx={{ textTransform: 'capitalize' }} />
                      </Stack>
                      <Typography variant="body2" color="text.secondary">{m.body}</Typography>
                      <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>{m.createdAt}</Typography>
                    </Box>
                    <Tooltip title="Delete">
                      <IconButton color="error" onClick={() => setToDelete(m.id)}><DeleteRounded /></IconButton>
                    </Tooltip>
                  </Stack>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}

      <MessageForm key={composeOpen ? 'compose' : 'closed'} open={composeOpen} mode="self" onClose={() => setComposeOpen(false)} onSubmit={handleSend} />
      <ConfirmDialog
        open={Boolean(toDelete)}
        title="Delete message?"
        message="This message will be permanently removed."
        onConfirm={confirmDelete}
        onClose={() => setToDelete(null)}
      />
    </Box>
  );
}
