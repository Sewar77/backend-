import { useEffect, useMemo, useState } from 'react';
import {
  Box, Container, Grid, TextField, MenuItem, InputAdornment, Pagination,
  Stack, Typography, Chip, Button,
} from '@mui/material';
import SearchRounded from '@mui/icons-material/SearchRounded';
import SortRounded from '@mui/icons-material/SortRounded';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { useNotification } from '../../context/NotificationContext';
import ServiceCard from '../../components/ServiceCard';
import ServiceDetailDialog from '../../components/Modals/ServiceDetailDialog';
import { CardSkeletonGrid } from '../../components/Skeletons';
import PageHeader from '../../components/PageHeader';

const PER_PAGE = 9;

const sortOptions = [
  { value: 'featured', label: 'Featured first' },
  { value: 'priceAsc', label: 'Price: low to high' },
  { value: 'priceDesc', label: 'Price: high to low' },
  { value: 'ratingDesc', label: 'Top rated' },
  { value: 'nameAsc', label: 'Name: A → Z' },
  { value: 'nameDesc', label: 'Name: Z → A' },
];

/**
 * Service catalog with search, category/status filters, sorting and pagination.
 * Favorites are enabled only for authenticated users.
 */
export default function Services() {
  const { services, categories, toggleFavorite, isFavorite } = useData();
  const { currentUser, isAuthenticated } = useAuth();
  const { notify } = useNotification();

  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');
  const [status, setStatus] = useState('all');
  const [sort, setSort] = useState('featured');
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState(null);

  // Simulate an async data fetch so the loading skeletons are visible.
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(t);
  }, []);

  const categoryById = useMemo(
    () => Object.fromEntries(categories.map((c) => [c.id, c])),
    [categories],
  );

  const filtered = useMemo(() => {
    let list = [...services];
    const q = search.trim().toLowerCase();
    if (q) list = list.filter((s) => s.name.toLowerCase().includes(q) || s.description.toLowerCase().includes(q));
    if (category !== 'all') list = list.filter((s) => s.categoryId === category);
    if (status !== 'all') list = list.filter((s) => s.status === status);

    switch (sort) {
      case 'priceAsc': list.sort((a, b) => a.price - b.price); break;
      case 'priceDesc': list.sort((a, b) => b.price - a.price); break;
      case 'ratingDesc': list.sort((a, b) => b.rating - a.rating); break;
      case 'nameAsc': list.sort((a, b) => a.name.localeCompare(b.name)); break;
      case 'nameDesc': list.sort((a, b) => b.name.localeCompare(a.name)); break;
      default: list.sort((a, b) => Number(b.featured) - Number(a.featured));
    }
    return list;
  }, [services, search, category, status, sort]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  // Clamp the page so it stays valid when filters shrink the result set.
  const safePage = Math.min(page, pageCount);
  const visible = filtered.slice((safePage - 1) * PER_PAGE, safePage * PER_PAGE);

  // Filter changes reset pagination back to the first page.
  const withReset = (setter) => (value) => { setter(value); setPage(1); };
  const onSearch = withReset(setSearch);
  const onCategory = withReset(setCategory);
  const onStatus = withReset(setStatus);
  const onSort = withReset(setSort);

  const handleFavorite = (serviceId) => {
    if (!isAuthenticated) {
      notify('Sign in to save favorites.', 'info');
      return;
    }
    toggleFavorite(currentUser.id, serviceId);
    notify(isFavorite(currentUser.id, serviceId) ? 'Removed from favorites.' : 'Added to favorites.', 'success');
  };

  const resetFilters = () => {
    setSearch(''); setCategory('all'); setStatus('all'); setSort('featured');
  };

  return (
    <Container maxWidth="xl" sx={{ py: { xs: 4, md: 6 } }}>
      <PageHeader
        title="Explore services"
        subtitle={`Browse our catalog of ${services.length} premium services.`}
      />

      {/* Filters */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, md: 4 }}>
          <TextField
            fullWidth placeholder="Search services…" value={search}
            onChange={(e) => onSearch(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchRounded fontSize="small" /></InputAdornment> }}
          />
        </Grid>
        <Grid size={{ xs: 6, md: 3 }}>
          <TextField select fullWidth label="Category" value={category} onChange={(e) => onCategory(e.target.value)}>
            <MenuItem value="all">All categories</MenuItem>
            {categories.map((c) => <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>)}
          </TextField>
        </Grid>
        <Grid size={{ xs: 6, md: 2 }}>
          <TextField select fullWidth label="Status" value={status} onChange={(e) => onStatus(e.target.value)}>
            <MenuItem value="all">All</MenuItem>
            <MenuItem value="active">Active</MenuItem>
            <MenuItem value="draft">Draft</MenuItem>
            <MenuItem value="archived">Archived</MenuItem>
          </TextField>
        </Grid>
        <Grid size={{ xs: 12, md: 3 }}>
          <TextField
            select fullWidth label="Sort by" value={sort} onChange={(e) => onSort(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><SortRounded fontSize="small" /></InputAdornment> }}
          >
            {sortOptions.map((o) => <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>)}
          </TextField>
        </Grid>
      </Grid>

      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
        <Chip label={`${filtered.length} result${filtered.length === 1 ? '' : 's'}`} color="primary" variant="outlined" />
        {(search || category !== 'all' || status !== 'all' || sort !== 'featured') && (
          <Button size="small" onClick={resetFilters}>Reset filters</Button>
        )}
      </Stack>

      {loading ? (
        <CardSkeletonGrid count={6} />
      ) : visible.length === 0 ? (
        <Box sx={{ textAlign: 'center', py: 10 }}>
          <Typography variant="h6">No services match your filters.</Typography>
          <Button variant="contained" sx={{ mt: 2 }} onClick={resetFilters}>Clear filters</Button>
        </Box>
      ) : (
        <Grid container spacing={3}>
          {visible.map((s) => (
            <Grid key={s.id} size={{ xs: 12, sm: 6, md: 4 }}>
              <ServiceCard
                service={s}
                category={categoryById[s.categoryId]}
                favorite={isAuthenticated && isFavorite(currentUser.id, s.id)}
                onToggleFavorite={handleFavorite}
                onView={setSelected}
                showFavorite
              />
            </Grid>
          ))}
        </Grid>
      )}

      {!loading && pageCount > 1 && (
        <Stack alignItems="center" sx={{ mt: 4 }}>
          <Pagination count={pageCount} page={safePage} onChange={(_, p) => setPage(p)} color="primary" shape="rounded" />
        </Stack>
      )}

      <ServiceDetailDialog
        open={Boolean(selected)}
        service={selected}
        category={selected ? categoryById[selected.categoryId] : null}
        favorite={Boolean(selected && isAuthenticated && isFavorite(currentUser.id, selected.id))}
        showFavorite={isAuthenticated}
        onToggleFavorite={handleFavorite}
        onClose={() => setSelected(null)}
      />
    </Container>
  );
}
