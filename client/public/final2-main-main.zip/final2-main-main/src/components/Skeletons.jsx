import { Card, CardContent, Skeleton, Grid, Box } from '@mui/material';

export function CardSkeletonGrid({ count = 6 }) {
  return (
    <Grid container spacing={3}>
      {Array.from({ length: count }).map((_, i) => (
        <Grid key={i} size={{ xs: 12, sm: 6, md: 4 }}>
          <Card>
            <Skeleton variant="rectangular" height={160} />
            <CardContent>
              <Skeleton width="40%" height={28} />
              <Skeleton width="80%" />
              <Skeleton width="60%" />
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 2 }}>
                <Skeleton width={60} height={32} />
                <Skeleton width={90} height={32} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
}

export function StatSkeletonRow({ count = 4 }) {
  return (
    <Grid container spacing={3}>
      {Array.from({ length: count }).map((_, i) => (
        <Grid key={i} size={{ xs: 12, sm: 6, md: 3 }}>
          <Card>
            <CardContent>
              <Skeleton width="50%" />
              <Skeleton width="35%" height={44} />
              <Skeleton width="40%" />
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
}
