import { useMemo, useState } from 'react';
import {
  Box, Grid, Card, CardContent, Typography, Button, Stack, Chip, Rating,
  Avatar, Tabs, Tab,
} from '@mui/material';
import CheckCircleRounded from '@mui/icons-material/CheckCircleRounded';
import CancelRounded from '@mui/icons-material/CancelRounded';
import DeleteRounded from '@mui/icons-material/DeleteRounded';
import { useData } from '../../context/DataContext';
import { useNotification } from '../../context/NotificationContext';
import PageHeader from '../../components/PageHeader';
import ConfirmDialog from '../../components/Modals/ConfirmDialog';
import { gradients } from '../../theme/theme';

const statusColor = { approved: 'success', pending: 'warning', rejected: 'error' };
const tabs = ['all', 'pending', 'approved', 'rejected'];

export default function AdminReviews() {
  const { reviews, services, setReviewStatus, deleteReview } = useData();
  const { notify } = useNotification();
  const [tab, setTab] = useState('all');
  const [toDelete, setToDelete] = useState(null);

  const serviceById = useMemo(() => Object.fromEntries(services.map((s) => [s.id, s])), [services]);
  const rows = useMemo(
    () => (tab === 'all' ? reviews : reviews.filter((r) => r.status === tab)),
    [reviews, tab],
  );

  const approve = (r) => { setReviewStatus(r.id, 'approved'); notify('Review approved.', 'success'); };
  const reject = (r) => { setReviewStatus(r.id, 'rejected'); notify('Review rejected.', 'info'); };
  const handleDelete = () => { deleteReview(toDelete.id); notify('Review deleted.', 'info'); setToDelete(null); };

  return (
    <Box>
      <PageHeader title="Reviews" subtitle={`Moderate ${reviews.length} community reviews.`} />

      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 3 }}>
        {tabs.map((t) => (
          <Tab key={t} value={t} label={t} sx={{ textTransform: 'capitalize' }} />
        ))}
      </Tabs>

      {rows.length === 0 ? (
        <Card sx={{ textAlign: 'center', py: 6 }}>
          <CardContent>
            <Typography variant="h6">No reviews in this view.</Typography>
          </CardContent>
        </Card>
      ) : (
        <Grid container spacing={3}>
          {rows.map((r) => (
            <Grid key={r.id} size={{ xs: 12, md: 6 }}>
              <Card sx={{ height: '100%' }}>
                <CardContent>
                  <Stack direction="row" justifyContent="space-between" alignItems="flex-start" sx={{ mb: 1 }}>
                    <Stack direction="row" spacing={1.5} alignItems="center">
                      <Avatar sx={{ background: gradients.primary }}>{r.author?.[0] ?? '?'}</Avatar>
                      <Box>
                        <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>{r.author}</Typography>
                        <Typography variant="caption" color="text.secondary">
                          on {serviceById[r.serviceId]?.name ?? 'a service'} · {r.createdAt}
                        </Typography>
                      </Box>
                    </Stack>
                    <Chip size="small" label={r.status} color={statusColor[r.status]} sx={{ textTransform: 'capitalize' }} />
                  </Stack>
                  <Rating value={r.rating} size="small" readOnly sx={{ mb: 1 }} />
                  <Typography variant="body2" color="text.secondary">{r.comment}</Typography>
                  <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
                    <Button size="small" variant="contained" color="success" startIcon={<CheckCircleRounded />} onClick={() => approve(r)} disabled={r.status === 'approved'}>Approve</Button>
                    <Button size="small" variant="outlined" color="warning" startIcon={<CancelRounded />} onClick={() => reject(r)} disabled={r.status === 'rejected'}>Reject</Button>
                    <Box sx={{ flexGrow: 1 }} />
                    <Button size="small" color="error" startIcon={<DeleteRounded />} onClick={() => setToDelete(r)}>Delete</Button>
                  </Stack>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}

      <ConfirmDialog
        open={Boolean(toDelete)}
        title="Delete review?"
        message="This review will be permanently removed."
        onConfirm={handleDelete}
        onClose={() => setToDelete(null)}
      />
    </Box>
  );
}
