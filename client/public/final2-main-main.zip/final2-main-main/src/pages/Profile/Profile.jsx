import { useState } from 'react';
import {
  Box, Grid, Card, CardContent, Typography, TextField, Button, Avatar, Stack,
  Chip, Divider,
} from '@mui/material';
import SaveRounded from '@mui/icons-material/SaveRounded';
import CalendarMonthRounded from '@mui/icons-material/CalendarMonthRounded';
import VerifiedRounded from '@mui/icons-material/VerifiedRounded';
import { useAuth } from '../../context/AuthContext';
import { useNotification } from '../../context/NotificationContext';
import PageHeader from '../../components/PageHeader';
import { gradients } from '../../theme/theme';

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function Profile() {
  const { currentUser, isAdmin, updateProfile } = useAuth();
  const { notify } = useNotification();
  const [form, setForm] = useState({
    name: currentUser?.name ?? '',
    email: currentUser?.email ?? '',
    bio: currentUser?.bio ?? '',
  });
  const [errors, setErrors] = useState({});

  const handle = (field) => (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = 'Name is required';
    if (!emailRe.test(form.email)) next.email = 'Valid email is required';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const save = (e) => {
    e.preventDefault();
    if (!validate()) return;
    updateProfile({ name: form.name.trim(), email: form.email.trim(), bio: form.bio });
    notify('Profile updated successfully.', 'success');
  };

  const dirty =
    form.name !== currentUser?.name ||
    form.email !== currentUser?.email ||
    form.bio !== (currentUser?.bio ?? '');

  return (
    <Box>
      <PageHeader title="Profile" subtitle="Manage your personal information." />

      <Grid container spacing={3}>
        <Grid size={{ xs: 12, md: 4 }}>
          <Card>
            <Box sx={{ height: 90, background: gradients.brand }} />
            <CardContent sx={{ textAlign: 'center', mt: -6 }}>
              <Avatar src={currentUser?.avatar} alt={currentUser?.name} sx={{ width: 96, height: 96, mx: 'auto', border: '4px solid', borderColor: 'background.paper', boxShadow: 3 }} />
              <Typography variant="h6" sx={{ fontWeight: 700, mt: 1.5 }}>{currentUser?.name}</Typography>
              <Typography variant="body2" color="text.secondary">{currentUser?.email}</Typography>
              <Stack direction="row" spacing={1} justifyContent="center" sx={{ mt: 1.5 }}>
                <Chip icon={<VerifiedRounded />} label={isAdmin ? 'Administrator' : 'Member'} color={isAdmin ? 'secondary' : 'primary'} />
              </Stack>
              <Divider sx={{ my: 2 }} />
              <Stack direction="row" spacing={1} alignItems="center" justifyContent="center" color="text.secondary">
                <CalendarMonthRounded fontSize="small" />
                <Typography variant="body2">Joined {currentUser?.joinedAt}</Typography>
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 8 }}>
          <Card component="form" onSubmit={save}>
            <CardContent sx={{ p: { xs: 2.5, md: 4 } }}>
              <Typography variant="h6" sx={{ fontWeight: 700, mb: 3 }}>Edit details</Typography>
              <Grid container spacing={2}>
                <Grid size={{ xs: 12, sm: 6 }}>
                  <TextField fullWidth label="Full name" value={form.name} onChange={handle('name')} error={!!errors.name} helperText={errors.name} />
                </Grid>
                <Grid size={{ xs: 12, sm: 6 }}>
                  <TextField fullWidth label="Email" value={form.email} onChange={handle('email')} error={!!errors.email} helperText={errors.email} />
                </Grid>
                <Grid size={12}>
                  <TextField fullWidth multiline minRows={3} label="Bio" value={form.bio} onChange={handle('bio')} />
                </Grid>
                <Grid size={12}>
                  <Button type="submit" variant="contained" startIcon={<SaveRounded />} disabled={!dirty}>Save changes</Button>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
