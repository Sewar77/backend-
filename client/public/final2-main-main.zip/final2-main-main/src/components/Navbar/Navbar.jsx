import { useState } from 'react';
import {
  AppBar, Toolbar, IconButton, Box, Typography, Avatar, Menu, MenuItem,
  ListItemIcon, Divider, Tooltip, Chip,
} from '@mui/material';
import MenuRounded from '@mui/icons-material/MenuRounded';
import PersonRounded from '@mui/icons-material/PersonRounded';
import LogoutRounded from '@mui/icons-material/LogoutRounded';
import DashboardRounded from '@mui/icons-material/DashboardRounded';
import { useNavigate } from 'react-router-dom';
import ThemeToggle from '../ThemeToggle';
import { useAuth } from '../../context/AuthContext';
import { useNotification } from '../../context/NotificationContext';


export default function Navbar({ title = 'Dashboard', onMenuClick }) {
  const navigate = useNavigate();
  const { currentUser, isAdmin, logout } = useAuth();
  const { notify } = useNotification();
  const [anchor, setAnchor] = useState(null);

  const handleLogout = () => {
    setAnchor(null);
    logout();
    notify('You have been signed out.', 'info');
    navigate('/login');
  };

  const go = (path) => {
    setAnchor(null);
    navigate(path);
  };

  return (
    <AppBar
      position="sticky"
      elevation={0}
      sx={{
        bgcolor: (t) =>
          t.palette.mode === 'dark' ? 'rgba(15,23,42,0.7)' : 'rgba(255,255,255,0.75)',
        backdropFilter: 'blur(14px)',
        borderBottom: (t) => `1px solid ${t.palette.divider}`,
        color: 'text.primary',
      }}
    >
      <Toolbar sx={{ gap: 1 }}>
        <IconButton
          edge="start"
          color="inherit"
          onClick={onMenuClick}
          sx={{ display: { lg: 'none' } }}
          aria-label="open sidebar"
        >
          <MenuRounded />
        </IconButton>
        <Typography variant="h6" sx={{ fontWeight: 700 }}>
          {title}
        </Typography>
        <Box sx={{ flexGrow: 1 }} />
        <ThemeToggle />
        <Tooltip title="Account">
          <IconButton onClick={(e) => setAnchor(e.currentTarget)} sx={{ ml: 0.5 }}>
            <Avatar src={currentUser?.avatar} alt={currentUser?.name} sx={{ width: 36, height: 36 }} />
          </IconButton>
        </Tooltip>

        <Menu
          anchorEl={anchor}
          open={Boolean(anchor)}
          onClose={() => setAnchor(null)}
          transformOrigin={{ horizontal: 'right', vertical: 'top' }}
          anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
          slotProps={{ paper: { sx: { mt: 1, minWidth: 220, borderRadius: 2 } } }}
        >
          <Box sx={{ px: 2, py: 1.2 }}>
            <Typography variant="subtitle1" noWrap>{currentUser?.name}</Typography>
            <Typography variant="body2" color="text.secondary" noWrap>{currentUser?.email}</Typography>
            <Chip
              size="small"
              label={isAdmin ? 'Administrator' : 'Member'}
              color={isAdmin ? 'secondary' : 'primary'}
              sx={{ mt: 0.8 }}
            />
          </Box>
          <Divider />
          <MenuItem onClick={() => go(isAdmin ? '/admin' : '/app')}>
            <ListItemIcon><DashboardRounded fontSize="small" /></ListItemIcon>
            {isAdmin ? 'Admin dashboard' : 'My dashboard'}
          </MenuItem>
          <MenuItem onClick={() => go(isAdmin ? '/admin/profile' : '/app/profile')}>
            <ListItemIcon><PersonRounded fontSize="small" /></ListItemIcon>
            Profile
          </MenuItem>
          <Divider />
          <MenuItem onClick={handleLogout}>
            <ListItemIcon><LogoutRounded fontSize="small" /></ListItemIcon>
            Sign out
          </MenuItem>
        </Menu>
      </Toolbar>
    </AppBar>
  );
}
