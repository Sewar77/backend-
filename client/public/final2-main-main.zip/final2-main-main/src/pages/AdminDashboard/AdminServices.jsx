import { useMemo, useState } from 'react';
import {
  Box, Button, Chip, Stack, IconButton, Tooltip, TextField, InputAdornment,
  MenuItem, Grid, Rating,
} from '@mui/material';
import AddRounded from '@mui/icons-material/AddRounded';
import EditRounded from '@mui/icons-material/EditRounded';
import DeleteRounded from '@mui/icons-material/DeleteRounded';
import SearchRounded from '@mui/icons-material/SearchRounded';
import StarRounded from '@mui/icons-material/StarRounded';
import { useData } from '../../context/DataContext';
import { useNotification } from '../../context/NotificationContext';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/Tables/DataTable';
import ServiceForm from '../../components/Forms/ServiceForm';
import ConfirmDialog from '../../components/Modals/ConfirmDialog';

const statusColor = { active: 'success', draft: 'warning', archived: 'default' };

export default function AdminServices() {
  const { services, categories, addService, updateService, deleteService } = useData();
  const { notify } = useNotification();

  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [toDelete, setToDelete] = useState(null);

  const categoryById = useMemo(() => Object.fromEntries(categories.map((c) => [c.id, c])), [categories]);

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return services.filter((s) => {
      const matchesQ = !q || s.name.toLowerCase().includes(q);
      const matchesCat = categoryFilter === 'all' || s.categoryId === categoryFilter;
      const matchesStatus = statusFilter === 'all' || s.status === statusFilter;
      return matchesQ && matchesCat && matchesStatus;
    });
  }, [services, search, categoryFilter, statusFilter]);

  const openCreate = () => { setEditing(null); setFormOpen(true); };
  const openEdit = (svc) => { setEditing(svc); setFormOpen(true); };

  const handleSubmit = (data) => {
    if (editing) {
      updateService(editing.id, data);
      notify('Service updated.', 'success');
    } else {
      addService(data);
      notify('Service created.', 'success');
    }
    setFormOpen(false);
  };

  const handleDelete = () => {
    deleteService(toDelete.id);
    notify('Service deleted.', 'info');
    setToDelete(null);
  };

  const columns = [
    { field: 'name', headerName: 'Service', flex: 1.4, minWidth: 200 },
    {
      field: 'categoryId', headerName: 'Category', width: 160,
      valueGetter: (value) => categoryById[value]?.name ?? '—',
      renderCell: (p) => <Chip size="small" variant="outlined" label={categoryById[p.row.categoryId]?.name ?? '—'} />,
    },
    { field: 'price', headerName: 'Price', width: 110, valueFormatter: (value) => `$${value}` },
    {
      field: 'rating', headerName: 'Rating', width: 150,
      renderCell: (p) => (
        <Stack direction="row" spacing={0.5} alignItems="center" sx={{ height: '100%' }}>
          <Rating value={p.value} precision={0.1} size="small" readOnly emptyIcon={<StarRounded sx={{ opacity: 0.25, fontSize: 18 }} />} />
        </Stack>
      ),
    },
    {
      field: 'status', headerName: 'Status', width: 120,
      renderCell: (p) => <Chip size="small" label={p.value} color={statusColor[p.value]} sx={{ textTransform: 'capitalize' }} />,
    },
    {
      field: 'actions', headerName: 'Actions', width: 110, sortable: false, filterable: false,
      renderCell: (p) => (
        <Stack direction="row" spacing={0.5}>
          <Tooltip title="Edit"><IconButton size="small" onClick={() => openEdit(p.row)}><EditRounded fontSize="small" /></IconButton></Tooltip>
          <Tooltip title="Delete"><IconButton size="small" color="error" onClick={() => setToDelete(p.row)}><DeleteRounded fontSize="small" /></IconButton></Tooltip>
        </Stack>
      ),
    },
  ];

  return (
    <Box>
      <PageHeader
        title="Services"
        subtitle={`Create, edit and manage ${services.length} services.`}
        action={<Button variant="contained" startIcon={<AddRounded />} onClick={openCreate}>Add service</Button>}
      />

      <Grid container spacing={2} sx={{ mb: 2 }}>
        <Grid size={{ xs: 12, md: 6 }}>
          <TextField fullWidth placeholder="Search services…" value={search} onChange={(e) => setSearch(e.target.value)} InputProps={{ startAdornment: <InputAdornment position="start"><SearchRounded fontSize="small" /></InputAdornment> }} />
        </Grid>
        <Grid size={{ xs: 6, md: 3 }}>
          <TextField select fullWidth label="Category" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
            <MenuItem value="all">All categories</MenuItem>
            {categories.map((c) => <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>)}
          </TextField>
        </Grid>
        <Grid size={{ xs: 6, md: 3 }}>
          <TextField select fullWidth label="Status" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <MenuItem value="all">All</MenuItem>
            <MenuItem value="active">Active</MenuItem>
            <MenuItem value="draft">Draft</MenuItem>
            <MenuItem value="archived">Archived</MenuItem>
          </TextField>
        </Grid>
      </Grid>

      <DataTable rows={rows} columns={columns} />

      <ServiceForm key={formOpen ? (editing?.id ?? 'new') : 'closed'} open={formOpen} initialData={editing} categories={categories} onSubmit={handleSubmit} onClose={() => setFormOpen(false)} />
      <ConfirmDialog
        open={Boolean(toDelete)}
        title="Delete service?"
        message={toDelete ? `"${toDelete.name}" will be permanently removed.` : ''}
        onConfirm={handleDelete}
        onClose={() => setToDelete(null)}
      />
    </Box>
  );
}
