import { Card, CardContent, Box, Typography, Avatar, Chip, Stack } from '@mui/material';
import TrendingUpRounded from '@mui/icons-material/TrendingUpRounded';


export default function StatCard({ title, value, icon, gradient, trend, subtitle }) {
  return (
    <Card
      sx={{
        position: 'relative',
        overflow: 'hidden',
        height: '100%',
        transition: 'transform .25s ease, box-shadow .25s ease',
        '&:hover': { transform: 'translateY(-4px)', boxShadow: '0 18px 40px rgba(2,6,23,0.25)' },
      }}
    >
      <Box sx={{ position: 'absolute', inset: 0, opacity: 0.12, background: gradient }} />
      <CardContent sx={{ position: 'relative' }}>
        <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
          <Box>
            <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 600 }}>
              {title}
            </Typography>
            <Typography variant="h4" sx={{ fontWeight: 800, mt: 0.5 }}>
              {value}
            </Typography>
          </Box>
          <Avatar sx={{ background: gradient, width: 52, height: 52, boxShadow: 3 }}>
            {icon}
          </Avatar>
        </Stack>
        <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 2 }}>
          {trend && (
            <Chip
              size="small"
              color="success"
              icon={<TrendingUpRounded sx={{ fontSize: 16 }} />}
              label={trend}
              sx={{ fontWeight: 700 }}
            />
          )}
          {subtitle && (
            <Typography variant="caption" color="text.secondary">{subtitle}</Typography>
          )}
        </Stack>
      </CardContent>
    </Card>
  );
}
