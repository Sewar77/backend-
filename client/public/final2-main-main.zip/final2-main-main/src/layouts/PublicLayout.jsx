import { Box } from '@mui/material';
import { Outlet } from 'react-router-dom';
import PublicNavbar from '../components/Navbar/PublicNavbar';
import Footer from '../components/Footer/Footer';
import { gradients } from '../theme/theme';

export default function PublicLayout() {
  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        background: (t) => (t.palette.mode === 'dark' ? gradients.darkPage : gradients.lightPage),
      }}
    >
      <PublicNavbar />
      <Box component="main" sx={{ flexGrow: 1 }}>
        <Outlet />
      </Box>
      <Footer />
    </Box>
  );
}
