import { createContext, useCallback, useContext, useEffect, useMemo } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { services as seedServices } from '../data/services';
import { categories as seedCategories } from '../data/categories';
import { reviews as seedReviews } from '../data/reviews';
import { messages as seedMessages } from '../data/messages';
import { users as seedUsers } from '../data/users';

const DataContext = createContext(null);

const uid = (prefix) => `${prefix}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;


export function DataProvider({ children }) {
  const [services, setServices] = useLocalStorage('servicehub_services', seedServices);
  const [categories, setCategories] = useLocalStorage('servicehub_categories', seedCategories);
  const [reviews, setReviews] = useLocalStorage('servicehub_reviews', seedReviews);
  const [messages, setMessages] = useLocalStorage('servicehub_messages', seedMessages);
  const [users, setUsers] = useLocalStorage('servicehub_accounts', seedUsers);
  const [favorites, setFavorites] = useLocalStorage('servicehub_favorites', {});

  useEffect(() => {
    const stats = {
      users: users.length,
      services: services.length,
      categories: categories.length,
      messages: messages.length,
      reviews: reviews.length,
      updatedAt: new Date().toISOString(),
    };
    try {
      window.localStorage.setItem('servicehub_stats', JSON.stringify(stats));
    } catch {/* ignore quota errors */}
  }, [users, services, categories, messages, reviews]);

  const addService = useCallback(
    (data) => setServices((prev) => [{ ...data, id: uid('srv'), rating: 0, reviewsCount: 0, createdAt: new Date().toISOString().slice(0, 10) }, ...prev]),
    [setServices],
  );
  const updateService = useCallback(
    (id, data) => setServices((prev) => prev.map((s) => (s.id === id ? { ...s, ...data } : s))),
    [setServices],
  );
  const deleteService = useCallback(
    (id) => setServices((prev) => prev.filter((s) => s.id !== id)),
    [setServices],
  );

  const addCategory = useCallback(
    (data) => setCategories((prev) => [{ ...data, id: uid('cat'), slug: data.name.toLowerCase().replace(/\s+/g, '-') }, ...prev]),
    [setCategories],
  );
  const updateCategory = useCallback(
    (id, data) => setCategories((prev) => prev.map((c) => (c.id === id ? { ...c, ...data } : c))),
    [setCategories],
  );
  const deleteCategory = useCallback(
    (id) => setCategories((prev) => prev.filter((c) => c.id !== id)),
    [setCategories],
  );

  const addUser = useCallback(
    (data) => setUsers((prev) => [{ ...data, id: uid('usr'), avatar: `https://i.pravatar.cc/150?u=${encodeURIComponent(data.email)}`, joinedAt: new Date().toISOString().slice(0, 10) }, ...prev]),
    [setUsers],
  );
  const updateUser = useCallback(
    (id, data) => setUsers((prev) => prev.map((u) => (u.id === id ? { ...u, ...data } : u))),
    [setUsers],
  );
  const deleteUser = useCallback(
    (id) => setUsers((prev) => prev.filter((u) => u.id !== id)),
    [setUsers],
  );
  const changeUserRole = useCallback(
    (id, role) => setUsers((prev) => prev.map((u) => (u.id === id ? { ...u, role } : u))),
    [setUsers],
  );

  const addMessage = useCallback(
    (data) => setMessages((prev) => [{ ...data, id: uid('msg'), status: 'unread', createdAt: new Date().toISOString().slice(0, 10) }, ...prev]),
    [setMessages],
  );
  const updateMessage = useCallback(
    (id, data) => setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, ...data } : m))),
    [setMessages],
  );
  const deleteMessage = useCallback(
    (id) => setMessages((prev) => prev.filter((m) => m.id !== id)),
    [setMessages],
  );

  const setReviewStatus = useCallback(
    (id, status) => setReviews((prev) => prev.map((r) => (r.id === id ? { ...r, status } : r))),
    [setReviews],
  );
  const deleteReview = useCallback(
    (id) => setReviews((prev) => prev.filter((r) => r.id !== id)),
    [setReviews],
  );

  const toggleFavorite = useCallback(
    (userId, serviceId) =>
      setFavorites((prev) => {
        const mine = new Set(prev[userId] ?? []);
        if (mine.has(serviceId)) mine.delete(serviceId);
        else mine.add(serviceId);
        return { ...prev, [userId]: [...mine] };
      }),
    [setFavorites],
  );
  const isFavorite = useCallback(
    (userId, serviceId) => Boolean(favorites[userId]?.includes(serviceId)),
    [favorites],
  );

  const value = useMemo(
    () => ({
      services, categories, reviews, messages, users, favorites,
      addService, updateService, deleteService,
      addCategory, updateCategory, deleteCategory,
      addUser, updateUser, deleteUser, changeUserRole,
      addMessage, updateMessage, deleteMessage,
      setReviewStatus, deleteReview,
      toggleFavorite, isFavorite,
    }),
    [
      services, categories, reviews, messages, users, favorites,
      addService, updateService, deleteService,
      addCategory, updateCategory, deleteCategory,
      addUser, updateUser, deleteUser, changeUserRole,
      addMessage, updateMessage, deleteMessage,
      setReviewStatus, deleteReview,
      toggleFavorite, isFavorite,
    ],
  );

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used within a DataProvider');
  return ctx;
}

export default DataContext;
