import { useState } from 'react';
import {
  Box, Container, Grid, Card, CardContent, Typography, TextField, Button,
  Stack, Avatar,
} from '@mui/material';
import EmailRounded from '@mui/icons-material/EmailRounded';
import PhoneRounded from '@mui/icons-material/PhoneRounded';
import LocationOnRounded from '@mui/icons-material/LocationOnRounded';
import SendRounded from '@mui/icons-material/SendRounded';
import { useData } from '../../context/DataContext';
import { useNotification } from '../../context/NotificationContext';
import { gradients } from '../../theme/theme';

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const contactInfo = [
  { icon: <EmailRounded />, label: 'Email', value: 'hello@servicehub.pro', g: gradients.primary },
  { icon: <PhoneRounded />, label: 'Phone', value: '+1 (555) 012-3456', g: gradients.accent },
  { icon: <LocationOnRounded />, label: 'Office', value: '500 Market St, San Francisco', g: gradients.success },
];

export default function Contact() {
  const { addMessage } = useData();
  const { notify } = useNotification();
  const [form, setForm] = useState({ name: '', email: '', subject: '', body: '' });
  const [errors, setErrors] = useState({});

  const handle = (field) => (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = 'Name is required';
    if (!emailRe.test(form.email)) next.email = 'Valid email is required';
    if (!form.subject.trim()) next.subject = 'Subject is required';
    if (!form.body.trim()) next.body = 'Message is required';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const submit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    addMessage({ fromName: form.name, fromEmail: form.email, subject: form.subject, body: form.body });
    notify('Thanks! Your message has been sent to our team.', 'success');
    setForm({ name: '', email: '', subject: '', body: '' });
  };

  return (
    <Container maxWidth="lg" sx={{ py: { xs: 6, md: 10 } }}>
      <Box sx={{ textAlign: 'center', mb: 6 }}>
        <Typography variant="h2" sx={{ fontWeight: 800, fontSize: { xs: '2.2rem', md: '3rem' } }}>Get in touch</Typography>
        <Typography variant="h6" color="text.secondary" sx={{ fontWeight: 400, mt: 1 }}>
          Have a question? We&apos;d love to hear from you.
        </Typography>
      </Box>

      <Grid container spacing={4}>
        <Grid size={{ xs: 12, md: 5 }}>
          <Stack spacing={2}>
            {contactInfo.map((c) => (
              <Card key={c.label}>
                <CardContent>
                  <Stack direction="row" spacing={2} alignItems="center">
                    <Avatar sx={{ background: c.g, boxShadow: 3 }}>{c.icon}</Avatar>
                    <Box>
                      <Typography variant="body2" color="text.secondary">{c.label}</Typography>
                      <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>{c.value}</Typography>
                    </Box>
                  </Stack>
                </CardContent>
              </Card>
            ))}
          </Stack>
        </Grid>

        <Grid size={{ xs: 12, md: 7 }}>
          <Card component="form" onSubmit={submit}>
            <CardContent sx={{ p: { xs: 2.5, md: 4 } }}>
              <Typography variant="h5" sx={{ fontWeight: 700, mb: 3 }}>Send us a message</Typography>
              <Grid container spacing={2}>
                <Grid size={{ xs: 12, sm: 6 }}>
                  <TextField fullWidth label="Your name" value={form.name} onChange={handle('name')} error={!!errors.name} helperText={errors.name} />
                </Grid>
                <Grid size={{ xs: 12, sm: 6 }}>
                  <TextField fullWidth label="Your email" value={form.email} onChange={handle('email')} error={!!errors.email} helperText={errors.email} />
                </Grid>
                <Grid size={12}>
                  <TextField fullWidth label="Subject" value={form.subject} onChange={handle('subject')} error={!!errors.subject} helperText={errors.subject} />
                </Grid>
                <Grid size={12}>
                  <TextField fullWidth multiline minRows={5} label="Message" value={form.body} onChange={handle('body')} error={!!errors.body} helperText={errors.body} />
                </Grid>
                <Grid size={12}>
                  <Button type="submit" variant="contained" size="large" endIcon={<SendRounded />}>Send message</Button>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
}
