import { useState } from 'react';
import {
  AppBar, Toolbar, Box, Button, Container, IconButton, Drawer,
  List, ListItem, ListItemButton, ListItemText, Divider, Stack,
} from '@mui/material';
import MenuRounded from '@mui/icons-material/MenuRounded';
import { NavLink, useNavigate } from 'react-router-dom';
import Logo from '../Logo';
import ThemeToggle from '../ThemeToggle';

const links = [
  { label: 'Home', to: '/' },
  { label: 'About', to: '/about' },
  { label: 'Services', to: '/services' },
];

export default function PublicNavbar() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const navButtonSx = ({ isActive }) => ({
    color: isActive ? 'primary.main' : 'text.primary',
    fontWeight: 600,
  });

  return (
    <AppBar
      position="sticky"
      elevation={0}
      sx={{
        bgcolor: (t) =>
          t.palette.mode === 'dark' ? 'rgba(15,23,42,0.6)' : 'rgba(255,255,255,0.6)',
        backdropFilter: 'blur(14px)',
        borderBottom: (t) => `1px solid ${t.palette.divider}`,
        color: 'text.primary',
      }}
    >
      <Container maxWidth="lg">
        <Toolbar disableGutters sx={{ gap: 2 }}>
          <Logo />
          <Box sx={{ flexGrow: 1 }} />
          <Stack direction="row" spacing={1} sx={{ display: { xs: 'none', md: 'flex' }, alignItems: 'center' }}>
            {links.map((l) => (
              <Button key={l.to} component={NavLink} to={l.to} end={l.to === '/'} sx={navButtonSx}>
                {l.label}
              </Button>
            ))}
            <ThemeToggle />
            <Button variant="text" onClick={() => navigate('/login')}>Login</Button>
            <Button variant="contained" onClick={() => navigate('/register')}>Get started</Button>
          </Stack>
          <Box sx={{ display: { xs: 'flex', md: 'none' }, alignItems: 'center' }}>
            <ThemeToggle />
            <IconButton color="inherit" onClick={() => setOpen(true)} aria-label="open navigation">
              <MenuRounded />
            </IconButton>
          </Box>
        </Toolbar>
      </Container>

      <Drawer anchor="right" open={open} onClose={() => setOpen(false)}>
        <Box sx={{ width: 260, p: 2 }} role="presentation" onClick={() => setOpen(false)}>
          <Logo />
          <List sx={{ mt: 1 }}>
            {links.map((l) => (
              <ListItem key={l.to} disablePadding>
                <ListItemButton component={NavLink} to={l.to} end={l.to === '/'}>
                  <ListItemText primary={l.label} />
                </ListItemButton>
              </ListItem>
            ))}
          </List>
          <Divider sx={{ my: 1 }} />
          <Stack spacing={1.2} sx={{ mt: 1 }}>
            <Button variant="outlined" fullWidth onClick={() => navigate('/login')}>Login</Button>
            <Button variant="contained" fullWidth onClick={() => navigate('/register')}>Get started</Button>
          </Stack>
        </Box>
      </Drawer>
    </AppBar>
  );
}
