import { BrowserRouter } from 'react-router-dom';
import { ColorModeProvider } from './context/ThemeContext';
import { NotificationProvider } from './context/NotificationContext';
import { DataProvider } from './context/DataContext';
import { AuthProvider } from './context/AuthContext';
import AppRoutes from './routes/AppRoutes';


export default function App() {
  return (
    <ColorModeProvider>
      <NotificationProvider>
        <DataProvider>
          <AuthProvider>
            <BrowserRouter>
              <AppRoutes />
            </BrowserRouter>
          </AuthProvider>
        </DataProvider>
      </NotificationProvider>
    </ColorModeProvider>
  );
}
