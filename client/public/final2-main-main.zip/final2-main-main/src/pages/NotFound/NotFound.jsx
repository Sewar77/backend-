import { Box, Button, Container, Typography, Stack } from '@mui/material';
import HomeRounded from '@mui/icons-material/HomeRounded';
import ArrowBackRounded from '@mui/icons-material/ArrowBackRounded';
import { useNavigate } from 'react-router-dom';
import Logo from '../../components/Logo';
import { gradients } from '../../theme/theme';

export default function NotFound() {
  const navigate = useNavigate();
  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
        p: 3,
        background: (t) => (t.palette.mode === 'dark' ? gradients.darkPage : gradients.lightPage),
      }}
    >
      <Container maxWidth="sm">
        <Box sx={{ mb: 4, display: 'flex', justifyContent: 'center' }}><Logo /></Box>
        <Typography
          sx={{
            fontWeight: 900,
            fontSize: { xs: '6rem', md: '9rem' },
            lineHeight: 1,
            background: gradients.brand,
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
          }}
        >
          404
        </Typography>
        <Typography variant="h4" sx={{ fontWeight: 800, mt: 1 }}>Page not found</Typography>
        <Typography variant="body1" color="text.secondary" sx={{ mt: 1.5, mb: 4 }}>
          The page you&apos;re looking for doesn&apos;t exist or has been moved.
        </Typography>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} justifyContent="center">
          <Button variant="outlined" startIcon={<ArrowBackRounded />} onClick={() => navigate(-1)}>Go back</Button>
          <Button variant="contained" startIcon={<HomeRounded />} onClick={() => navigate('/')}>Back home</Button>
        </Stack>
      </Container>
    </Box>
  );
}
