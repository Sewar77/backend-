import {
  Box, Container, Grid, Card, CardContent, Typography, Avatar, Stack,
  Button, Chip, Rating, Divider,
} from '@mui/material';
import RocketLaunchRounded from '@mui/icons-material/RocketLaunchRounded';
import BoltRounded from '@mui/icons-material/BoltRounded';
import ShieldRounded from '@mui/icons-material/ShieldRounded';
import InsightsRounded from '@mui/icons-material/InsightsRounded';
import PaletteRounded from '@mui/icons-material/PaletteRounded';
import DevicesRounded from '@mui/icons-material/DevicesRounded';
import FavoriteRounded from '@mui/icons-material/FavoriteRounded';
import ArrowForwardRounded from '@mui/icons-material/ArrowForwardRounded';
import { useNavigate } from 'react-router-dom';
import Hero from '../../components/Hero/Hero';
import { gradients } from '../../theme/theme';

const features = [
  { icon: <BoltRounded />, title: 'Lightning fast', desc: 'A snappy, modern experience built on React and Vite for instant interactions.', g: gradients.primary },
  { icon: <PaletteRounded />, title: 'Beautiful by default', desc: 'Glassmorphism, gradients and a custom MUI theme out of the box.', g: gradients.accent },
  { icon: <ShieldRounded />, title: 'Role-based access', desc: 'Separate, secure experiences for members and administrators.', g: gradients.success },
  { icon: <InsightsRounded />, title: 'Live analytics', desc: 'Track services, users and messages with real-time charts.', g: gradients.primary },
  { icon: <DevicesRounded />, title: 'Fully responsive', desc: 'Pixel-perfect across desktop, tablet and mobile devices.', g: gradients.accent },
  { icon: <FavoriteRounded />, title: 'Favorites & feedback', desc: 'Save the services you love and share feedback with the team.', g: gradients.success },
];

const stats = [
  { value: '12k+', label: 'Active users' },
  { value: '30+', label: 'Premium services' },
  { value: '99.9%', label: 'Uptime' },
  { value: '4.9/5', label: 'Avg. rating' },
];

const testimonials = [
  { name: 'Sarah Lin', role: 'Founder, Nimbus', text: 'ServiceHub Pro completely changed how we discover and manage vendors. The UI is gorgeous.', avatar: 'https://i.pravatar.cc/150?img=47' },
  { name: 'Marcus Reed', role: 'CTO, Flowbase', text: 'The analytics dashboard alone is worth it. Our team finally has visibility into everything.', avatar: 'https://i.pravatar.cc/150?img=15' },
  { name: 'Aisha Khan', role: 'PM, Brightly', text: 'Beautiful, fast and intuitive. Onboarding our whole company took less than a day.', avatar: 'https://i.pravatar.cc/150?img=32' },
];

export default function Landing() {
  const navigate = useNavigate();

  return (
    <Box>
      <Hero />

      {/* Stats */}
      <Container maxWidth="lg" sx={{ mb: { xs: 8, md: 12 } }}>
        <Card sx={{ p: { xs: 2, md: 4 }, background: (t) => (t.palette.mode === 'dark' ? 'rgba(30,41,59,0.6)' : 'rgba(255,255,255,0.7)'), backdropFilter: 'blur(12px)' }}>
          <Grid container spacing={2}>
            {stats.map((s) => (
              <Grid key={s.label} size={{ xs: 6, md: 3 }} sx={{ textAlign: 'center' }}>
                <Typography variant="h3" sx={{ fontWeight: 800, background: gradients.brand, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                  {s.value}
                </Typography>
                <Typography variant="body2" color="text.secondary">{s.label}</Typography>
              </Grid>
            ))}
          </Grid>
        </Card>
      </Container>

      {/* Features */}
      <Container maxWidth="lg" sx={{ mb: { xs: 8, md: 12 } }}>
        <Box sx={{ textAlign: 'center', mb: 6 }}>
          <Chip label="Features" color="primary" variant="outlined" sx={{ mb: 2, fontWeight: 600 }} />
          <Typography variant="h3" sx={{ fontWeight: 800 }}>Everything you need to scale</Typography>
          <Typography variant="h6" color="text.secondary" sx={{ fontWeight: 400, mt: 1, maxWidth: 560, mx: 'auto' }}>
            A complete toolkit to discover services, manage your workspace and grow with confidence.
          </Typography>
        </Box>
        <Grid container spacing={3}>
          {features.map((f) => (
            <Grid key={f.title} size={{ xs: 12, sm: 6, md: 4 }}>
              <Card sx={{ height: '100%', transition: 'transform .25s ease, box-shadow .25s ease', '&:hover': { transform: 'translateY(-6px)', boxShadow: '0 20px 44px rgba(2,6,23,0.25)' } }}>
                <CardContent>
                  <Avatar sx={{ background: f.g, width: 52, height: 52, mb: 2, boxShadow: 3 }}>{f.icon}</Avatar>
                  <Typography variant="h6" sx={{ fontWeight: 700 }}>{f.title}</Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>{f.desc}</Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Testimonials */}
      <Container maxWidth="lg" sx={{ mb: { xs: 8, md: 12 } }}>
        <Box sx={{ textAlign: 'center', mb: 6 }}>
          <Chip label="Loved by teams" color="secondary" variant="outlined" sx={{ mb: 2, fontWeight: 600 }} />
          <Typography variant="h3" sx={{ fontWeight: 800 }}>What our customers say</Typography>
        </Box>
        <Grid container spacing={3}>
          {testimonials.map((t) => (
            <Grid key={t.name} size={{ xs: 12, md: 4 }}>
              <Card sx={{ height: '100%' }}>
                <CardContent>
                  <Rating value={5} readOnly size="small" sx={{ mb: 1.5 }} />
                  <Typography variant="body1" sx={{ fontStyle: 'italic' }}>“{t.text}”</Typography>
                  <Divider sx={{ my: 2 }} />
                  <Stack direction="row" spacing={1.5} alignItems="center">
                    <Avatar src={t.avatar} alt={t.name} />
                    <Box>
                      <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>{t.name}</Typography>
                      <Typography variant="caption" color="text.secondary">{t.role}</Typography>
                    </Box>
                  </Stack>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* CTA */}
      <Container maxWidth="lg" sx={{ mb: { xs: 8, md: 14 } }}>
        <Card sx={{ position: 'relative', overflow: 'hidden', textAlign: 'center', p: { xs: 4, md: 8 }, color: '#fff', background: gradients.brand }}>
          <Box sx={{ position: 'absolute', inset: 0, opacity: 0.25, background: 'radial-gradient(circle at 20% 20%, #fff, transparent 40%)' }} />
          <Box sx={{ position: 'relative' }}>
            <RocketLaunchRounded sx={{ fontSize: 56, mb: 2 }} />
            <Typography variant="h3" sx={{ fontWeight: 800, mb: 1 }}>Ready to get started?</Typography>
            <Typography variant="h6" sx={{ fontWeight: 400, opacity: 0.9, mb: 4 }}>
              Join thousands of teams building on ServiceHub Pro today.
            </Typography>
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} justifyContent="center">
              <Button size="large" variant="contained" color="inherit" endIcon={<ArrowForwardRounded />} onClick={() => navigate('/register')} sx={{ color: 'primary.main', bgcolor: '#fff', px: 4, '&:hover': { bgcolor: '#f1f5f9' } }}>
                Create free account
              </Button>
              <Button size="large" variant="outlined" color="inherit" onClick={() => navigate('/login')} sx={{ px: 4, borderColor: 'rgba(255,255,255,0.6)' }}>
                Sign in
              </Button>
            </Stack>
          </Box>
        </Card>
      </Container>
    </Box>
  );
}
