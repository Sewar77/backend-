import { useMemo, useState } from 'react';
import {
  Box, Button, Chip, Avatar, Stack, IconButton, Tooltip, TextField,
  InputAdornment, MenuItem, Grid,
} from '@mui/material';
import AddRounded from '@mui/icons-material/AddRounded';
import EditRounded from '@mui/icons-material/EditRounded';
import DeleteRounded from '@mui/icons-material/DeleteRounded';
import SearchRounded from '@mui/icons-material/SearchRounded';
import AdminPanelSettingsRounded from '@mui/icons-material/AdminPanelSettingsRounded';
import PersonRounded from '@mui/icons-material/PersonRounded';
import SwapHorizRounded from '@mui/icons-material/SwapHorizRounded';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { useNotification } from '../../context/NotificationContext';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/Tables/DataTable';
import UserForm from '../../components/Forms/UserForm';
import ConfirmDialog from '../../components/Modals/ConfirmDialog';

export default function AdminUsers() {
  const { users, addUser, updateUser, deleteUser, changeUserRole } = useData();
  const { currentUser } = useAuth();
  const { notify } = useNotification();

  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [toDelete, setToDelete] = useState(null);

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return users.filter((u) => {
      const matchesQ = !q || u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q);
      const matchesRole = roleFilter === 'all' || u.role === roleFilter;
      return matchesQ && matchesRole;
    });
  }, [users, search, roleFilter]);

  const openCreate = () => { setEditing(null); setFormOpen(true); };
  const openEdit = (user) => { setEditing(user); setFormOpen(true); };

  const handleSubmit = (data) => {
    if (editing) {
      updateUser(editing.id, data);
      notify('User updated.', 'success');
    } else {
      addUser(data);
      notify('User created.', 'success');
    }
    setFormOpen(false);
  };

  const handleDelete = () => {
    deleteUser(toDelete.id);
    notify('User deleted.', 'info');
    setToDelete(null);
  };

  const toggleRole = (user) => {
    const next = user.role === 'admin' ? 'user' : 'admin';
    changeUserRole(user.id, next);
    notify(`${user.name} is now ${next === 'admin' ? 'an admin' : 'a user'}.`, 'success');
  };

  const columns = [
    {
      field: 'name', headerName: 'User', flex: 1.4, minWidth: 220,
      renderCell: (params) => (
        <Stack direction="row" spacing={1.5} alignItems="center" sx={{ height: '100%' }}>
          <Avatar src={params.row.avatar} sx={{ width: 34, height: 34 }} />
          <Box sx={{ minWidth: 0 }}>
            <Box sx={{ fontWeight: 600, lineHeight: 1.2 }}>{params.row.name}</Box>
            <Box sx={{ fontSize: 12, color: 'text.secondary' }}>{params.row.email}</Box>
          </Box>
        </Stack>
      ),
    },
    {
      field: 'role', headerName: 'Role', width: 120,
      renderCell: (p) => (
        <Chip
          size="small"
          icon={p.value === 'admin' ? <AdminPanelSettingsRounded sx={{ fontSize: 16 }} /> : <PersonRounded sx={{ fontSize: 16 }} />}
          label={p.value}
          color={p.value === 'admin' ? 'secondary' : 'default'}
          sx={{ textTransform: 'capitalize' }}
        />
      ),
    },
    {
      field: 'status', headerName: 'Status', width: 120,
      renderCell: (p) => <Chip size="small" label={p.value} color={p.value === 'active' ? 'success' : 'default'} sx={{ textTransform: 'capitalize' }} />,
    },
    { field: 'joinedAt', headerName: 'Joined', width: 130 },
    {
      field: 'actions', headerName: 'Actions', width: 150, sortable: false, filterable: false,
      renderCell: (p) => {
        const isSelf = p.row.id === currentUser.id;
        return (
          <Stack direction="row" spacing={0.5}>
            <Tooltip title="Toggle role"><span><IconButton size="small" onClick={() => toggleRole(p.row)} disabled={isSelf}><SwapHorizRounded fontSize="small" /></IconButton></span></Tooltip>
            <Tooltip title="Edit"><IconButton size="small" onClick={() => openEdit(p.row)}><EditRounded fontSize="small" /></IconButton></Tooltip>
            <Tooltip title="Delete"><span><IconButton size="small" color="error" onClick={() => setToDelete(p.row)} disabled={isSelf}><DeleteRounded fontSize="small" /></IconButton></span></Tooltip>
          </Stack>
        );
      },
    },
  ];

  return (
    <Box>
      <PageHeader
        title="Users"
        subtitle={`Manage ${users.length} accounts, roles and access.`}
        action={<Button variant="contained" startIcon={<AddRounded />} onClick={openCreate}>Add user</Button>}
      />

      <Grid container spacing={2} sx={{ mb: 2 }}>
        <Grid size={{ xs: 12, sm: 8 }}>
          <TextField fullWidth placeholder="Search users…" value={search} onChange={(e) => setSearch(e.target.value)} InputProps={{ startAdornment: <InputAdornment position="start"><SearchRounded fontSize="small" /></InputAdornment> }} />
        </Grid>
        <Grid size={{ xs: 12, sm: 4 }}>
          <TextField select fullWidth label="Role" value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)}>
            <MenuItem value="all">All roles</MenuItem>
            <MenuItem value="admin">Admins</MenuItem>
            <MenuItem value="user">Users</MenuItem>
          </TextField>
        </Grid>
      </Grid>

      <DataTable rows={rows} columns={columns} />

      <UserForm key={formOpen ? (editing?.id ?? 'new') : 'closed'} open={formOpen} initialData={editing} onSubmit={handleSubmit} onClose={() => setFormOpen(false)} />
      <ConfirmDialog
        open={Boolean(toDelete)}
        title="Delete user?"
        message={toDelete ? `${toDelete.name} will be permanently removed.` : ''}
        onConfirm={handleDelete}
        onClose={() => setToDelete(null)}
      />
    </Box>
  );
}
