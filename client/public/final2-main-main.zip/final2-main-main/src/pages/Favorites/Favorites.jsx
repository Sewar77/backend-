import { useMemo, useState } from 'react';
import { Box, Grid, Button, Typography, Card, CardContent, Avatar } from '@mui/material';
import FavoriteRounded from '@mui/icons-material/FavoriteRounded';
import GridViewRounded from '@mui/icons-material/GridViewRounded';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { useNotification } from '../../context/NotificationContext';
import ServiceCard from '../../components/ServiceCard';
import ServiceDetailDialog from '../../components/Modals/ServiceDetailDialog';
import PageHeader from '../../components/PageHeader';
import { gradients } from '../../theme/theme';

export default function Favorites() {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const { services, categories, favorites, toggleFavorite, isFavorite } = useData();
  const { notify } = useNotification();
  const [selected, setSelected] = useState(null);

  const categoryById = useMemo(() => Object.fromEntries(categories.map((c) => [c.id, c])), [categories]);
  const favoriteServices = useMemo(() => {
    const ids = favorites[currentUser.id] ?? [];
    return services.filter((s) => ids.includes(s.id));
  }, [services, favorites, currentUser.id]);

  const handleToggle = (serviceId) => {
    const was = isFavorite(currentUser.id, serviceId);
    toggleFavorite(currentUser.id, serviceId);
    notify(was ? 'Removed from favorites.' : 'Added to favorites.', was ? 'info' : 'success');
  };

  return (
    <Box>
      <PageHeader
        title="My favorites"
        subtitle="The services you've saved for later."
        action={<Button variant="contained" startIcon={<GridViewRounded />} onClick={() => navigate('/app/services')}>Browse more</Button>}
      />

      {favoriteServices.length === 0 ? (
        <Card sx={{ textAlign: 'center', py: 8 }}>
          <CardContent>
            <Avatar sx={{ background: gradients.accent, width: 72, height: 72, mx: 'auto', mb: 2 }}>
              <FavoriteRounded sx={{ fontSize: 36 }} />
            </Avatar>
            <Typography variant="h6" sx={{ fontWeight: 700 }}>No favorites yet</Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1, mb: 3 }}>
              Tap the heart on any service to save it here.
            </Typography>
            <Button variant="contained" onClick={() => navigate('/app/services')}>Explore services</Button>
          </CardContent>
        </Card>
      ) : (
        <Grid container spacing={3}>
          {favoriteServices.map((s) => (
            <Grid key={s.id} size={{ xs: 12, sm: 6, md: 4 }}>
              <ServiceCard
                service={s}
                category={categoryById[s.categoryId]}
                favorite
                onToggleFavorite={handleToggle}
                onView={setSelected}
              />
            </Grid>
          ))}
        </Grid>
      )}

      <ServiceDetailDialog
        open={Boolean(selected)}
        service={selected}
        category={selected ? categoryById[selected.categoryId] : null}
        favorite={Boolean(selected)}
        showFavorite
        onToggleFavorite={handleToggle}
        onClose={() => setSelected(null)}
      />
    </Box>
  );
}
