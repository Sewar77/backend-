import Code from '@mui/icons-material/Code';
import PhoneIphone from '@mui/icons-material/PhoneIphone';
import Brush from '@mui/icons-material/Brush';
import Cloud from '@mui/icons-material/Cloud';
import Insights from '@mui/icons-material/Insights';
import Campaign from '@mui/icons-material/Campaign';
import Security from '@mui/icons-material/Security';
import Handshake from '@mui/icons-material/Handshake';
import Article from '@mui/icons-material/Article';
import SupportAgent from '@mui/icons-material/SupportAgent';
import Category from '@mui/icons-material/Category';

const ICONS = {
  Code, PhoneIphone, Brush, Cloud, Insights,
  Campaign, Security, Handshake, Article, SupportAgent,
};


export default function CategoryIcon({ name, ...props }) {
  const Icon = ICONS[name] ?? Category;
  return <Icon {...props} />;
}
