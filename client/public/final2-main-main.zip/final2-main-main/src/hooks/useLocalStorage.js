import { useCallback, useEffect, useState } from 'react';

export default function useLocalStorage(key, initialValue) {
  const readValue = useCallback(() => {
    if (typeof window === 'undefined') {
      return initialValue instanceof Function ? initialValue() : initialValue;
    }
    try {
      const item = window.localStorage.getItem(key);
      if (item !== null) return JSON.parse(item);
    } catch (error) {
      console.warn(`useLocalStorage: failed reading "${key}"`, error);
    }
    return initialValue instanceof Function ? initialValue() : initialValue;
  }, [key, initialValue]);

  const [storedValue, setStoredValue] = useState(readValue);

  const setValue = useCallback(
    (value) => {
      setStoredValue((prev) => {
        const next = value instanceof Function ? value(prev) : value;
        try {
          window.localStorage.setItem(key, JSON.stringify(next));
        } catch (error) {
          console.warn(`useLocalStorage: failed writing "${key}"`, error);
        }
        return next;
      });
    },
    [key],
  );

  const removeValue = useCallback(() => {
    try {
      window.localStorage.removeItem(key);
    } catch (error) {
      console.warn(`useLocalStorage: failed removing "${key}"`, error);
    }
    setStoredValue(initialValue instanceof Function ? initialValue() : initialValue);
  }, [key, initialValue]);

  useEffect(() => {
    const onStorage = (event) => {
      if (event.key === key) setStoredValue(readValue());
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, [key, readValue]);

  return [storedValue, setValue, removeValue];
}
