import { useMemo, useState } from 'react';
import { Box, Container } from '@mui/material';
import { Outlet, useLocation } from 'react-router-dom';
import DashboardRounded from '@mui/icons-material/DashboardRounded';
import GroupRounded from '@mui/icons-material/GroupRounded';
import GridViewRounded from '@mui/icons-material/GridViewRounded';
import CategoryRounded from '@mui/icons-material/CategoryRounded';
import MailRounded from '@mui/icons-material/MailRounded';
import RateReviewRounded from '@mui/icons-material/RateReviewRounded';
import AssessmentRounded from '@mui/icons-material/AssessmentRounded';
import PersonRounded from '@mui/icons-material/PersonRounded';
import Navbar from '../components/Navbar/Navbar';
import Sidebar from '../components/Sidebar/Sidebar';
import { gradients } from '../theme/theme';

const items = [
  { label: 'Dashboard', to: '/admin', end: true, icon: <DashboardRounded /> },
  { label: 'Users', to: '/admin/users', icon: <GroupRounded /> },
  { label: 'Services', to: '/admin/services', icon: <GridViewRounded /> },
  { label: 'Categories', to: '/admin/categories', icon: <CategoryRounded /> },
  { label: 'Messages', to: '/admin/messages', icon: <MailRounded /> },
  { label: 'Reviews', to: '/admin/reviews', icon: <RateReviewRounded /> },
  { label: 'Reports', to: '/admin/reports', icon: <AssessmentRounded /> },
  { label: 'Profile', to: '/admin/profile', icon: <PersonRounded /> },
];

const titles = {
  '/admin': 'Admin Dashboard',
  '/admin/users': 'Users',
  '/admin/services': 'Services',
  '/admin/categories': 'Categories',
  '/admin/messages': 'Messages',
  '/admin/reviews': 'Reviews',
  '/admin/reports': 'Reports',
  '/admin/profile': 'Profile',
};

export default function AdminLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const title = useMemo(() => titles[location.pathname] ?? 'Admin', [location.pathname]);

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', background: (t) => (t.palette.mode === 'dark' ? gradients.darkPage : gradients.lightPage) }}>
      <Sidebar items={items} mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} label="Administration" />
      <Box sx={{ flexGrow: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <Navbar title={title} onMenuClick={() => setMobileOpen(true)} />
        <Container maxWidth="xl" sx={{ py: 4, flexGrow: 1 }}>
          <Outlet />
        </Container>
      </Box>
    </Box>
  );
}
