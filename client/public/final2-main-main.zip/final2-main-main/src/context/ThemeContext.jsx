import { createContext, useCallback, useContext, useMemo } from 'react';
import { ThemeProvider as MuiThemeProvider, CssBaseline } from '@mui/material';
import useLocalStorage from '../hooks/useLocalStorage';
import { buildTheme } from '../theme/theme';

const ThemeModeContext = createContext(null);


export function ColorModeProvider({ children }) {
  const [mode, setMode] = useLocalStorage('servicehub_theme', 'dark');

  const toggleMode = useCallback(
    () => setMode((prev) => (prev === 'dark' ? 'light' : 'dark')),
    [setMode],
  );

  const theme = useMemo(() => buildTheme(mode), [mode]);

  const value = useMemo(
    () => ({ mode, setMode, toggleMode }),
    [mode, setMode, toggleMode],
  );

  return (
    <ThemeModeContext.Provider value={value}>
      <MuiThemeProvider theme={theme}>
        <CssBaseline />
        {children}
      </MuiThemeProvider>
    </ThemeModeContext.Provider>
  );
}

export function useThemeMode() {
  const ctx = useContext(ThemeModeContext);
  if (!ctx) throw new Error('useThemeMode must be used within a ColorModeProvider');
  return ctx;
}

export default ThemeModeContext;
