import { useMemo, useState } from 'react';
import {
  Box, Chip, Stack, IconButton, Tooltip, Tabs, Tab, Dialog, DialogTitle,
  DialogContent, DialogActions, Button, Typography, Divider,
} from '@mui/material';
import EditRounded from '@mui/icons-material/EditRounded';
import DeleteRounded from '@mui/icons-material/DeleteRounded';
import VisibilityRounded from '@mui/icons-material/VisibilityRounded';
import MarkEmailReadRounded from '@mui/icons-material/MarkEmailReadRounded';
import { useData } from '../../context/DataContext';
import { useNotification } from '../../context/NotificationContext';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/Tables/DataTable';
import MessageForm from '../../components/Forms/MessageForm';
import ConfirmDialog from '../../components/Modals/ConfirmDialog';

const statusColor = { unread: 'warning', read: 'info', replied: 'success' };
const tabs = ['all', 'unread', 'read', 'replied'];

export default function AdminMessages() {
  const { messages, updateMessage, deleteMessage } = useData();
  const { notify } = useNotification();

  const [tab, setTab] = useState('all');
  const [editing, setEditing] = useState(null);
  const [viewing, setViewing] = useState(null);
  const [toDelete, setToDelete] = useState(null);

  const rows = useMemo(
    () => (tab === 'all' ? messages : messages.filter((m) => m.status === tab)),
    [messages, tab],
  );

  const handleSubmit = (data) => {
    updateMessage(editing.id, data);
    notify('Message updated.', 'success');
    setEditing(null);
  };

  const handleDelete = () => {
    deleteMessage(toDelete.id);
    notify('Message deleted.', 'info');
    setToDelete(null);
  };

  const markReplied = (msg) => {
    updateMessage(msg.id, { status: 'replied' });
    notify('Marked as replied.', 'success');
  };

  const openView = (msg) => {
    setViewing(msg);
    if (msg.status === 'unread') updateMessage(msg.id, { status: 'read' });
  };

  const columns = [
    { field: 'fromName', headerName: 'From', width: 160 },
    { field: 'subject', headerName: 'Subject', flex: 1.2, minWidth: 200 },
    {
      field: 'status', headerName: 'Status', width: 120,
      renderCell: (p) => <Chip size="small" label={p.value} color={statusColor[p.value]} sx={{ textTransform: 'capitalize' }} />,
    },
    { field: 'createdAt', headerName: 'Date', width: 130 },
    {
      field: 'actions', headerName: 'Actions', width: 180, sortable: false, filterable: false,
      renderCell: (p) => (
        <Stack direction="row" spacing={0.5}>
          <Tooltip title="View"><IconButton size="small" onClick={() => openView(p.row)}><VisibilityRounded fontSize="small" /></IconButton></Tooltip>
          <Tooltip title="Mark replied"><IconButton size="small" color="success" onClick={() => markReplied(p.row)}><MarkEmailReadRounded fontSize="small" /></IconButton></Tooltip>
          <Tooltip title="Edit"><IconButton size="small" onClick={() => setEditing(p.row)}><EditRounded fontSize="small" /></IconButton></Tooltip>
          <Tooltip title="Delete"><IconButton size="small" color="error" onClick={() => setToDelete(p.row)}><DeleteRounded fontSize="small" /></IconButton></Tooltip>
        </Stack>
      ),
    },
  ];

  return (
    <Box>
      <PageHeader title="Messages" subtitle={`Manage ${messages.length} inbound messages.`} />

      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2 }}>
        {tabs.map((t) => (
          <Tab key={t} value={t} label={t} sx={{ textTransform: 'capitalize' }} />
        ))}
      </Tabs>

      <DataTable rows={rows} columns={columns} />

      {/* View dialog */}
      <Dialog open={Boolean(viewing)} onClose={() => setViewing(null)} maxWidth="sm" fullWidth slotProps={{ paper: { sx: { borderRadius: 3 } } }}>
        {viewing && (
          <>
            <DialogTitle>{viewing.subject}</DialogTitle>
            <DialogContent dividers>
              <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
                <Typography variant="subtitle2">{viewing.fromName}</Typography>
                <Typography variant="body2" color="text.secondary">&lt;{viewing.fromEmail}&gt;</Typography>
                <Chip size="small" label={viewing.status} color={statusColor[viewing.status]} sx={{ textTransform: 'capitalize' }} />
              </Stack>
              <Typography variant="caption" color="text.secondary">{viewing.createdAt}</Typography>
              <Divider sx={{ my: 2 }} />
              <Typography variant="body1">{viewing.body}</Typography>
            </DialogContent>
            <DialogActions sx={{ p: 2.5 }}>
              <Button color="inherit" onClick={() => setViewing(null)}>Close</Button>
              <Button variant="contained" onClick={() => { markReplied(viewing); setViewing(null); }}>Mark replied</Button>
            </DialogActions>
          </>
        )}
      </Dialog>

      <MessageForm key={editing?.id ?? 'closed'} open={Boolean(editing)} initialData={editing} mode="admin" onSubmit={handleSubmit} onClose={() => setEditing(null)} />
      <ConfirmDialog
        open={Boolean(toDelete)}
        title="Delete message?"
        message={toDelete ? `Message "${toDelete.subject}" will be permanently removed.` : ''}
        onConfirm={handleDelete}
        onClose={() => setToDelete(null)}
      />
    </Box>
  );
}
