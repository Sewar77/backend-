export const categories = [
  { id: 'cat-1', name: 'Web Development', slug: 'web-development', icon: 'Code', color: '#6366F1', description: 'Websites, web apps and everything in between.' },
  { id: 'cat-2', name: 'Mobile Apps', slug: 'mobile-apps', icon: 'PhoneIphone', color: '#8B5CF6', description: 'iOS and Android native & cross-platform apps.' },
  { id: 'cat-3', name: 'UI / UX Design', slug: 'ui-ux-design', icon: 'Brush', color: '#06B6D4', description: 'Product, interface and experience design.' },
  { id: 'cat-4', name: 'Cloud & DevOps', slug: 'cloud-devops', icon: 'Cloud', color: '#10B981', description: 'Infrastructure, CI/CD and reliability.' },
  { id: 'cat-5', name: 'Data & AI', slug: 'data-ai', icon: 'Insights', color: '#F59E0B', description: 'Analytics, ML pipelines and AI products.' },
  { id: 'cat-6', name: 'Marketing', slug: 'marketing', icon: 'Campaign', color: '#EF4444', description: 'Growth, SEO and performance marketing.' },
  { id: 'cat-7', name: 'Cybersecurity', slug: 'cybersecurity', icon: 'Security', color: '#3B82F6', description: 'Audits, pentesting and compliance.' },
  { id: 'cat-8', name: 'Consulting', slug: 'consulting', icon: 'Handshake', color: '#A78BFA', description: 'Strategy and technical advisory.' },
  { id: 'cat-9', name: 'Content & Copy', slug: 'content-copy', icon: 'Article', color: '#14B8A6', description: 'Copywriting, docs and content strategy.' },
  { id: 'cat-10', name: 'Support', slug: 'support', icon: 'SupportAgent', color: '#F472B6', description: 'Customer success and managed support.' },
];

export default categories;
