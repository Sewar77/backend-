import { Box, Button, Chip, Container, Stack, Typography } from '@mui/material';
import ArrowForwardRounded from '@mui/icons-material/ArrowForwardRounded';
import PlayArrowRounded from '@mui/icons-material/PlayArrowRounded';
import AutoAwesomeRounded from '@mui/icons-material/AutoAwesomeRounded';
import { useNavigate } from 'react-router-dom';
import { gradients } from '../../theme/theme';

export default function Hero() {
  const navigate = useNavigate();

  return (
    <Box sx={{ position: 'relative', overflow: 'hidden', pt: { xs: 8, md: 14 }, pb: { xs: 8, md: 16 } }}>
      {/* Decorative gradient blobs */}
      <Box sx={{ position: 'absolute', top: -120, left: -120, width: 360, height: 360, borderRadius: '50%', background: gradients.primary, filter: 'blur(120px)', opacity: 0.45 }} />
      <Box sx={{ position: 'absolute', bottom: -160, right: -100, width: 420, height: 420, borderRadius: '50%', background: gradients.accent, filter: 'blur(140px)', opacity: 0.35 }} />

      <Container maxWidth="md" sx={{ position: 'relative', textAlign: 'center' }}>
        <Chip
          icon={<AutoAwesomeRounded />}
          label="The all-in-one services platform"
          color="primary"
          variant="outlined"
          sx={{ mb: 3, fontWeight: 600, borderRadius: 999, px: 1 }}
        />
        <Typography
          variant="h1"
          sx={{ fontSize: { xs: '2.6rem', md: '4.2rem' }, lineHeight: 1.05, mb: 2 }}
        >
          Build, ship and grow with{' '}
          <Box
            component="span"
            sx={{
              background: gradients.brand,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            ServiceHub Pro
          </Box>
        </Typography>
        <Typography variant="h6" color="text.secondary" sx={{ fontWeight: 400, maxWidth: 640, mx: 'auto', mb: 4 }}>
          Discover premium services, manage your workspace, and run analytics — all from a single,
          beautifully crafted dashboard your whole team will love.
        </Typography>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} justifyContent="center">
          <Button
            size="large"
            variant="contained"
            endIcon={<ArrowForwardRounded />}
            onClick={() => navigate('/register')}
            sx={{ px: 4, py: 1.3 }}
          >
            Start for free
          </Button>
          <Button
            size="large"
            variant="outlined"
            startIcon={<PlayArrowRounded />}
            onClick={() => navigate('/services')}
            sx={{ px: 4, py: 1.3 }}
          >
            Browse services
          </Button>
        </Stack>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 3 }}>
          No credit card required · Free demo accounts included
        </Typography>
      </Container>
    </Box>
  );
}
