import { useState } from 'react';
import {
  Box, Typography, TextField, Button, Stack, InputAdornment, IconButton,
  Divider, Alert, Link, Card,
} from '@mui/material';
import EmailRounded from '@mui/icons-material/EmailRounded';
import LockRounded from '@mui/icons-material/LockRounded';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import { Link as RouterLink, useNavigate, useLocation } from 'react-router-dom';
import AuthShell from '../../components/AuthShell';
import { useAuth } from '../../context/AuthContext';
import { useNotification } from '../../context/NotificationContext';

const demoAccounts = [
  { label: 'Admin', email: 'admin@test.com', password: '123456' },
  { label: 'User', email: 'user@test.com', password: '123456' },
];

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  const { notify } = useNotification();

  const [form, setForm] = useState({ email: '', password: '' });
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');

  const handle = (field) => (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const submit = (e) => {
    e.preventDefault();
    setError('');
    const result = login(form.email, form.password);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    notify(`Welcome back, ${result.user.name}!`, 'success');
    const isAdmin = result.user.role === 'admin';
    const fallback = isAdmin ? '/admin' : '/app';
    const from = location.state?.from?.pathname;
    navigate(from && from !== '/login' ? from : fallback, { replace: true });
  };

  const fillDemo = (acc) => setForm({ email: acc.email, password: acc.password });

  return (
    <AuthShell>
      <Box component="form" onSubmit={submit}>
        <Typography variant="h4" sx={{ fontWeight: 800 }}>Welcome back</Typography>
        <Typography variant="body1" color="text.secondary" sx={{ mt: 0.5, mb: 3 }}>
          Sign in to continue to your workspace.
        </Typography>

        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        <Stack spacing={2}>
          <TextField
            fullWidth size="medium" label="Email" type="email" required
            value={form.email} onChange={handle('email')}
            InputProps={{ startAdornment: <InputAdornment position="start"><EmailRounded fontSize="small" /></InputAdornment> }}
          />
          <TextField
            fullWidth size="medium" label="Password" required
            type={showPw ? 'text' : 'password'}
            value={form.password} onChange={handle('password')}
            InputProps={{
              startAdornment: <InputAdornment position="start"><LockRounded fontSize="small" /></InputAdornment>,
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton onClick={() => setShowPw((s) => !s)} edge="end" aria-label="toggle password">
                    {showPw ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
          <Button type="submit" variant="contained" size="large" fullWidth>Sign in</Button>
        </Stack>

        <Divider sx={{ my: 3 }}>Try a demo account</Divider>
        <Stack direction="row" spacing={2}>
          {demoAccounts.map((acc) => (
            <Card key={acc.label} variant="outlined" sx={{ flex: 1, p: 1.5, cursor: 'pointer', '&:hover': { borderColor: 'primary.main' } }} onClick={() => fillDemo(acc)}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>{acc.label}</Typography>
              <Typography variant="caption" color="text.secondary" display="block">{acc.email}</Typography>
              <Typography variant="caption" color="text.secondary">pwd: {acc.password}</Typography>
            </Card>
          ))}
        </Stack>

        <Typography variant="body2" sx={{ mt: 3, textAlign: 'center' }} color="text.secondary">
          Don&apos;t have an account?{' '}
          <Link component={RouterLink} to="/register" underline="hover" sx={{ fontWeight: 700 }}>
            Create one
          </Link>
        </Typography>
      </Box>
    </AuthShell>
  );
}
