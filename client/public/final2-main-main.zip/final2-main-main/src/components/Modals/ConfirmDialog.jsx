import {
  Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions,
  Button, Box, Avatar,
} from '@mui/material';
import WarningAmberRounded from '@mui/icons-material/WarningAmberRounded';


export default function ConfirmDialog({
  open,
  title = 'Are you sure?',
  message = 'This action cannot be undone.',
  confirmText = 'Delete',
  cancelText = 'Cancel',
  confirmColor = 'error',
  onConfirm,
  onClose,
}) {
  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth slotProps={{ paper: { sx: { borderRadius: 3 } } }}>
      <Box sx={{ display: 'flex', justifyContent: 'center', pt: 3 }}>
        <Avatar sx={{ bgcolor: `${confirmColor}.main`, width: 56, height: 56 }}>
          <WarningAmberRounded />
        </Avatar>
      </Box>
      <DialogTitle sx={{ textAlign: 'center', pb: 0.5 }}>{title}</DialogTitle>
      <DialogContent>
        <DialogContentText sx={{ textAlign: 'center' }}>{message}</DialogContentText>
      </DialogContent>
      <DialogActions sx={{ p: 2.5, pt: 1, gap: 1 }}>
        <Button fullWidth variant="outlined" color="inherit" onClick={onClose}>{cancelText}</Button>
        <Button fullWidth variant="contained" color={confirmColor} onClick={onConfirm}>{confirmText}</Button>
      </DialogActions>
    </Dialog>
  );
}
