import {
  Dialog, DialogContent, DialogActions, Button, Box, Typography, Chip,
  Rating, Stack, Divider, IconButton,
} from '@mui/material';
import CloseRounded from '@mui/icons-material/CloseRounded';
import ScheduleRounded from '@mui/icons-material/ScheduleRounded';
import FavoriteRounded from '@mui/icons-material/FavoriteRounded';
import FavoriteBorderRounded from '@mui/icons-material/FavoriteBorderRounded';
import CategoryIcon from '../iconMap';


export default function ServiceDetailDialog({
  open, service, category, favorite = false, showFavorite = false, onToggleFavorite, onClose,
}) {
  if (!service) return null;
  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth slotProps={{ paper: { sx: { borderRadius: 3, overflow: 'hidden' } } }}>
      <Box sx={{ position: 'relative' }}>
        <Box component="img" src={service.image} alt={service.name} sx={{ width: '100%', height: 220, objectFit: 'cover' }} />
        <IconButton onClick={onClose} sx={{ position: 'absolute', top: 8, right: 8, bgcolor: 'rgba(0,0,0,0.5)', color: '#fff', '&:hover': { bgcolor: 'rgba(0,0,0,0.7)' } }}>
          <CloseRounded />
        </IconButton>
      </Box>
      <DialogContent>
        <Stack direction="row" spacing={1} sx={{ mb: 1 }}>
          {category && (
            <Chip size="small" icon={<CategoryIcon name={category.icon} sx={{ fontSize: 16 }} />} label={category.name} variant="outlined" />
          )}
          {service.featured && <Chip size="small" color="secondary" label="Featured" />}
        </Stack>
        <Typography variant="h5" sx={{ fontWeight: 800 }}>{service.name}</Typography>
        <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 1 }}>
          <Rating value={service.rating} precision={0.1} size="small" readOnly />
          <Typography variant="body2" color="text.secondary">{service.rating} ({service.reviewsCount} reviews)</Typography>
        </Stack>
        <Typography variant="body1" color="text.secondary" sx={{ mt: 2 }}>{service.description}</Typography>
        <Divider sx={{ my: 2 }} />
        <Stack direction="row" justifyContent="space-between" alignItems="center">
          <Stack direction="row" spacing={0.5} alignItems="center" color="text.secondary">
            <ScheduleRounded sx={{ fontSize: 18 }} />
            <Typography variant="body2">{service.deliveryDays} day delivery</Typography>
          </Stack>
          <Typography variant="h5" sx={{ fontWeight: 800, color: 'primary.main' }}>${service.price}</Typography>
        </Stack>
        {service.tags?.length > 0 && (
          <Stack direction="row" spacing={1} sx={{ mt: 2, flexWrap: 'wrap', gap: 1 }}>
            {service.tags.map((t) => <Chip key={t} size="small" label={t} />)}
          </Stack>
        )}
      </DialogContent>
      <DialogActions sx={{ p: 2.5 }}>
        {showFavorite && (
          <Button
            color="inherit"
            startIcon={favorite ? <FavoriteRounded color="error" /> : <FavoriteBorderRounded />}
            onClick={() => onToggleFavorite?.(service.id)}
          >
            {favorite ? 'Saved' : 'Save'}
          </Button>
        )}
        <Box sx={{ flexGrow: 1 }} />
        <Button variant="contained" onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
}
