import { useState } from 'react';
import {
  Box, Typography, TextField, Button, Stack, InputAdornment, IconButton,
  Alert, Link, LinearProgress,
} from '@mui/material';
import PersonRounded from '@mui/icons-material/PersonRounded';
import EmailRounded from '@mui/icons-material/EmailRounded';
import LockRounded from '@mui/icons-material/LockRounded';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import AuthShell from '../../components/AuthShell';
import { useAuth } from '../../context/AuthContext';
import { useNotification } from '../../context/NotificationContext';

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const strengthOf = (pw) => {
  let score = 0;
  if (pw.length >= 6) score += 1;
  if (/[A-Z]/.test(pw)) score += 1;
  if (/[0-9]/.test(pw)) score += 1;
  if (/[^A-Za-z0-9]/.test(pw)) score += 1;
  return score;
};

export default function Register() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const { notify } = useNotification();

  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [showPw, setShowPw] = useState(false);
  const [errors, setErrors] = useState({});
  const [error, setError] = useState('');

  const handle = (field) => (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = 'Full name is required';
    if (!emailRe.test(form.email)) next.email = 'Enter a valid email';
    if (form.password.length < 6) next.password = 'At least 6 characters';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const submit = (e) => {
    e.preventDefault();
    setError('');
    if (!validate()) return;
    const result = register(form);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    notify('Account created — welcome to ServiceHub Pro!', 'success');
    navigate('/app', { replace: true });
  };

  const strength = strengthOf(form.password);
  const strengthColor = ['error', 'error', 'warning', 'info', 'success'][strength];
  const strengthLabel = ['Too weak', 'Weak', 'Fair', 'Good', 'Strong'][strength];

  return (
    <AuthShell>
      <Box component="form" onSubmit={submit}>
        <Typography variant="h4" sx={{ fontWeight: 800 }}>Create your account</Typography>
        <Typography variant="body1" color="text.secondary" sx={{ mt: 0.5, mb: 3 }}>
          Start exploring ServiceHub Pro in seconds.
        </Typography>

        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        <Stack spacing={2}>
          <TextField
            fullWidth size="medium" label="Full name" required
            value={form.name} onChange={handle('name')}
            error={!!errors.name} helperText={errors.name}
            InputProps={{ startAdornment: <InputAdornment position="start"><PersonRounded fontSize="small" /></InputAdornment> }}
          />
          <TextField
            fullWidth size="medium" label="Email" type="email" required
            value={form.email} onChange={handle('email')}
            error={!!errors.email} helperText={errors.email}
            InputProps={{ startAdornment: <InputAdornment position="start"><EmailRounded fontSize="small" /></InputAdornment> }}
          />
          <Box>
            <TextField
              fullWidth size="medium" label="Password" required
              type={showPw ? 'text' : 'password'}
              value={form.password} onChange={handle('password')}
              error={!!errors.password} helperText={errors.password}
              InputProps={{
                startAdornment: <InputAdornment position="start"><LockRounded fontSize="small" /></InputAdornment>,
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton onClick={() => setShowPw((s) => !s)} edge="end" aria-label="toggle password">
                      {showPw ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
            {form.password && (
              <Box sx={{ mt: 1 }}>
                <LinearProgress variant="determinate" value={(strength / 4) * 100} color={strengthColor} sx={{ height: 6, borderRadius: 3 }} />
                <Typography variant="caption" color={`${strengthColor}.main`}>{strengthLabel}</Typography>
              </Box>
            )}
          </Box>
          <Button type="submit" variant="contained" size="large" fullWidth>Create account</Button>
        </Stack>

        <Typography variant="body2" sx={{ mt: 3, textAlign: 'center' }} color="text.secondary">
          Already have an account?{' '}
          <Link component={RouterLink} to="/login" underline="hover" sx={{ fontWeight: 700 }}>
            Sign in
          </Link>
        </Typography>
      </Box>
    </AuthShell>
  );
}
