import { useState } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button, Grid,
  TextField, MenuItem, FormControlLabel, Switch, Stack,
} from '@mui/material';

const EMPTY = {
  name: '', categoryId: '', description: '', price: 199,
  status: 'active', featured: false, deliveryDays: 7, tags: '',
  image: '',
};


export default function ServiceForm({ open, initialData, categories, onSubmit, onClose }) {
  const isEdit = Boolean(initialData);
  const [form, setForm] = useState(() =>
    initialData
      ? { ...EMPTY, ...initialData, tags: (initialData.tags ?? []).join(', ') }
      : { ...EMPTY, categoryId: categories[0]?.id ?? '' },
  );
  const [errors, setErrors] = useState({});

  const handle = (field) => (e) => {
    const value = field === 'featured' ? e.target.checked : e.target.value;
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = 'Name is required';
    if (!form.categoryId) next.categoryId = 'Category is required';
    if (!form.description.trim()) next.description = 'Description is required';
    if (Number(form.price) < 0) next.price = 'Price must be positive';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const submit = () => {
    if (!validate()) return;
    onSubmit({
      ...form,
      price: Number(form.price),
      deliveryDays: Number(form.deliveryDays),
      tags: form.tags.split(',').map((t) => t.trim()).filter(Boolean),
      image: form.image || `https://picsum.photos/seed/${encodeURIComponent(form.name)}/640/360`,
    });
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth slotProps={{ paper: { sx: { borderRadius: 3 } } }}>
      <DialogTitle>{isEdit ? 'Edit service' : 'Create service'}</DialogTitle>
      <DialogContent dividers>
        <Grid container spacing={2} sx={{ mt: 0 }}>
          <Grid size={12}>
            <TextField fullWidth label="Service name" value={form.name} onChange={handle('name')} error={!!errors.name} helperText={errors.name} />
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <TextField select fullWidth label="Category" value={form.categoryId} onChange={handle('categoryId')} error={!!errors.categoryId} helperText={errors.categoryId}>
              {categories.map((c) => (
                <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>
              ))}
            </TextField>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <TextField select fullWidth label="Status" value={form.status} onChange={handle('status')}>
              {['active', 'draft', 'archived'].map((s) => (
                <MenuItem key={s} value={s} sx={{ textTransform: 'capitalize' }}>{s}</MenuItem>
              ))}
            </TextField>
          </Grid>
          <Grid size={12}>
            <TextField fullWidth multiline minRows={3} label="Description" value={form.description} onChange={handle('description')} error={!!errors.description} helperText={errors.description} />
          </Grid>
          <Grid size={{ xs: 6 }}>
            <TextField fullWidth type="number" label="Price ($)" value={form.price} onChange={handle('price')} error={!!errors.price} helperText={errors.price} />
          </Grid>
          <Grid size={{ xs: 6 }}>
            <TextField fullWidth type="number" label="Delivery (days)" value={form.deliveryDays} onChange={handle('deliveryDays')} />
          </Grid>
          <Grid size={12}>
            <TextField fullWidth label="Tags (comma separated)" value={form.tags} onChange={handle('tags')} placeholder="popular, pro" />
          </Grid>
          <Grid size={12}>
            <Stack direction="row" justifyContent="space-between" alignItems="center">
              <FormControlLabel control={<Switch checked={form.featured} onChange={handle('featured')} />} label="Featured service" />
            </Stack>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions sx={{ p: 2.5 }}>
        <Button color="inherit" onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={submit}>{isEdit ? 'Save changes' : 'Create'}</Button>
      </DialogActions>
    </Dialog>
  );
}
