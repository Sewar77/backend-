const subjects = [
  'Question about pricing',
  'Need help choosing a service',
  'Partnership opportunity',
  'Bug report on dashboard',
  'Feature request: dark mode',
  'Billing inquiry',
  'How do favorites work?',
  'Request for a custom quote',
  'Account upgrade question',
  'Feedback on the new design',
];

const bodies = [
  'Hi team, I would love to understand the pricing tiers in more detail before committing.',
  'Could you point me to the best service for an early-stage startup?',
  'We run a complementary product and would like to explore a partnership.',
  'The analytics chart seems to flicker when I resize the window.',
  'Loving the platform — a system-wide dark mode would be amazing.',
  'I was charged twice this month, can you take a look?',
  'I tried saving a favorite but it disappeared after refresh.',
  'We need a tailored package for an enterprise rollout.',
  'What do I get if I upgrade my account to pro?',
  'The new landing page looks fantastic, great job!',
];

const statuses = ['unread', 'read', 'replied'];

export const messages = Array.from({ length: 20 }, (_, i) => ({
  id: `msg-${i + 1}`,
  fromUserId: `usr-${(i % 20) + 1}`,
  fromName: ['Alex Carter', 'Jordan Nguyen', 'Taylor Patel', 'Morgan Garcia', 'Casey Kim'][i % 5],
  fromEmail: ['alex@servicehub.io', 'jordan@servicehub.io', 'taylor@servicehub.io', 'morgan@servicehub.io', 'casey@servicehub.io'][i % 5],
  subject: subjects[i % subjects.length],
  body: bodies[i % bodies.length],
  status: statuses[i % statuses.length],
  createdAt: `2025-${String((i % 12) + 1).padStart(2, '0')}-${String((i % 27) + 1).padStart(2, '0')}`,
}));

export default messages;
