import {
  Card, CardMedia, CardContent, CardActions, Box, Typography, Chip,
  Rating, IconButton, Button, Stack, Tooltip,
} from '@mui/material';
import FavoriteRounded from '@mui/icons-material/FavoriteRounded';
import FavoriteBorderRounded from '@mui/icons-material/FavoriteBorderRounded';
import ScheduleRounded from '@mui/icons-material/ScheduleRounded';
import CategoryIcon from './iconMap';


export default function ServiceCard({
  service, category, favorite = false, onToggleFavorite, onView, showFavorite = true,
}) {
  return (
    <Card
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        transition: 'transform .25s ease, box-shadow .25s ease',
        '&:hover': { transform: 'translateY(-6px)', boxShadow: '0 22px 48px rgba(2,6,23,0.28)' },
        '&:hover .svc-media': { transform: 'scale(1.06)' },
      }}
    >
      <Box sx={{ position: 'relative', overflow: 'hidden' }}>
        <CardMedia
          className="svc-media"
          component="img"
          height="160"
          image={service.image}
          alt={service.name}
          sx={{ transition: 'transform .4s ease' }}
        />
        {service.featured && (
          <Chip size="small" color="secondary" label="Featured" sx={{ position: 'absolute', top: 12, left: 12, fontWeight: 700 }} />
        )}
        {showFavorite && (
          <Tooltip title={favorite ? 'Remove favorite' : 'Add to favorites'}>
            <IconButton
              onClick={() => onToggleFavorite?.(service.id)}
              sx={{
                position: 'absolute', top: 8, right: 8,
                bgcolor: 'rgba(15,23,42,0.45)', color: '#fff',
                '&:hover': { bgcolor: 'rgba(15,23,42,0.65)' },
              }}
            >
              {favorite ? <FavoriteRounded color="error" /> : <FavoriteBorderRounded />}
            </IconButton>
          </Tooltip>
        )}
      </Box>

      <CardContent sx={{ flexGrow: 1 }}>
        <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
          {category && (
            <Chip
              size="small"
              icon={<CategoryIcon name={category.icon} sx={{ fontSize: 16 }} />}
              label={category.name}
              variant="outlined"
            />
          )}
          <Chip
            size="small"
            label={service.status}
            color={service.status === 'active' ? 'success' : service.status === 'draft' ? 'warning' : 'default'}
            sx={{ textTransform: 'capitalize' }}
          />
        </Stack>
        <Typography variant="h6" sx={{ fontWeight: 700, lineHeight: 1.2 }}>{service.name}</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5, minHeight: 40 }}>
          {service.description}
        </Typography>
        <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 1.5 }}>
          <Rating value={service.rating} precision={0.1} size="small" readOnly />
          <Typography variant="caption" color="text.secondary">
            {service.rating} ({service.reviewsCount})
          </Typography>
        </Stack>
        <Stack direction="row" spacing={0.5} alignItems="center" sx={{ mt: 1, color: 'text.secondary' }}>
          <ScheduleRounded sx={{ fontSize: 16 }} />
          <Typography variant="caption">{service.deliveryDays} day delivery</Typography>
        </Stack>
      </CardContent>

      <CardActions sx={{ px: 2, pb: 2, pt: 0, justifyContent: 'space-between' }}>
        <Typography variant="h6" sx={{ fontWeight: 800, color: 'primary.main' }}>
          ${service.price}
        </Typography>
        <Button size="small" variant="contained" onClick={() => onView?.(service)}>
          View details
        </Button>
      </CardActions>
    </Card>
  );
}
