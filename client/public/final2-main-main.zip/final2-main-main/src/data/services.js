const titles = [
  ['Landing Page Sprint', 'cat-1', 'Conversion-focused landing page built in one week.'],
  ['Full-Stack Web App', 'cat-1', 'End-to-end product build with React and Node.'],
  ['E-commerce Storefront', 'cat-1', 'Headless commerce store with payments.'],
  ['Progressive Web App', 'cat-1', 'Installable, offline-first web experience.'],
  ['iOS App Development', 'cat-2', 'Native Swift app shipped to the App Store.'],
  ['Android App Development', 'cat-2', 'Kotlin app built for scale and speed.'],
  ['React Native App', 'cat-2', 'Cross-platform app from a single codebase.'],
  ['Mobile UX Audit', 'cat-2', 'Heuristic review of your mobile flows.'],
  ['Design System', 'cat-3', 'Reusable component library and tokens.'],
  ['Product Redesign', 'cat-3', 'Modern refresh of your core product.'],
  ['Wireframe Package', 'cat-3', 'Low to high fidelity wireframes.'],
  ['Brand Identity Kit', 'cat-3', 'Logo, palette and brand guidelines.'],
  ['Kubernetes Setup', 'cat-4', 'Production-grade cluster and pipelines.'],
  ['CI/CD Pipeline', 'cat-4', 'Automated build, test and deploy flow.'],
  ['Cloud Migration', 'cat-4', 'Lift-and-shift to AWS, GCP or Azure.'],
  ['Cost Optimization', 'cat-4', 'Reduce your monthly cloud spend.'],
  ['Analytics Dashboard', 'cat-5', 'Real-time KPIs and reporting.'],
  ['ML Model Training', 'cat-5', 'Custom model trained on your data.'],
  ['Data Pipeline', 'cat-5', 'Reliable ETL into your warehouse.'],
  ['AI Chatbot', 'cat-5', 'LLM assistant tailored to your product.'],
  ['SEO Growth Plan', 'cat-6', 'Technical and content SEO roadmap.'],
  ['Paid Ads Campaign', 'cat-6', 'Performance marketing across channels.'],
  ['Email Automation', 'cat-6', 'Lifecycle email sequences that convert.'],
  ['Security Audit', 'cat-7', 'Full-stack vulnerability assessment.'],
  ['Penetration Test', 'cat-7', 'Simulated attack on your systems.'],
  ['Compliance Review', 'cat-7', 'SOC2 and GDPR readiness check.'],
  ['Tech Strategy Session', 'cat-8', 'Roadmap and architecture advisory.'],
  ['Fractional CTO', 'cat-8', 'Senior technical leadership on demand.'],
  ['Documentation Pack', 'cat-9', 'Developer and product documentation.'],
  ['Managed Support Plan', 'cat-10', '24/7 monitoring and customer support.'],
];

const statuses = ['active', 'active', 'active', 'draft', 'archived'];
const tagPool = ['popular', 'new', 'pro', 'enterprise', 'startup', 'fast'];

export const services = titles.map(([name, categoryId, description], i) => ({
  id: `srv-${i + 1}`,
  name,
  categoryId,
  description,
  price: 199 + ((i * 137) % 20) * 50,
  rating: Number((3.6 + ((i * 7) % 14) / 10).toFixed(1)),
  reviewsCount: 8 + ((i * 13) % 90),
  status: statuses[i % statuses.length],
  featured: i % 4 === 0,
  tags: [tagPool[i % tagPool.length], tagPool[(i + 3) % tagPool.length]],
  deliveryDays: 3 + (i % 21),
  image: `https://picsum.photos/seed/servicehub-${i + 1}/640/360`,
  createdAt: `2025-${String((i % 12) + 1).padStart(2, '0')}-${String((i % 27) + 1).padStart(2, '0')}`,
}));

export default services;
