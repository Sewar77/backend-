import {
  Box, Container, Grid, Card, CardContent, Typography, Avatar, Stack, Chip, Divider,
} from '@mui/material';
import FlagRounded from '@mui/icons-material/FlagRounded';
import VisibilityRounded from '@mui/icons-material/VisibilityRounded';
import GroupsRounded from '@mui/icons-material/GroupsRounded';
import { gradients } from '../../theme/theme';

const values = [
  { icon: <FlagRounded />, title: 'Our mission', desc: 'Make discovering and managing world-class digital services effortless for every team.', g: gradients.primary },
  { icon: <VisibilityRounded />, title: 'Our vision', desc: 'A connected ecosystem where great services and great teams find each other instantly.', g: gradients.accent },
  { icon: <GroupsRounded />, title: 'Our values', desc: 'Craft, transparency and obsessive attention to the user experience.', g: gradients.success },
];

const team = [
  { name: 'Elena Rossi', role: 'CEO & Co-founder', avatar: 'https://i.pravatar.cc/150?img=45' },
  { name: 'David Park', role: 'CTO & Co-founder', avatar: 'https://i.pravatar.cc/150?img=13' },
  { name: 'Maya Patel', role: 'Head of Design', avatar: 'https://i.pravatar.cc/150?img=20' },
  { name: 'Liam Walsh', role: 'Head of Growth', avatar: 'https://i.pravatar.cc/150?img=51' },
];

export default function About() {
  return (
    <Container maxWidth="lg" sx={{ py: { xs: 6, md: 10 } }}>
      <Box sx={{ textAlign: 'center', mb: 8 }}>
        <Chip label="About us" color="primary" variant="outlined" sx={{ mb: 2, fontWeight: 600 }} />
        <Typography variant="h2" sx={{ fontWeight: 800, fontSize: { xs: '2.2rem', md: '3.2rem' } }}>
          We&apos;re building the future of{' '}
          <Box component="span" sx={{ background: gradients.brand, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            service discovery
          </Box>
        </Typography>
        <Typography variant="h6" color="text.secondary" sx={{ fontWeight: 400, mt: 2, maxWidth: 680, mx: 'auto' }}>
          ServiceHub Pro started with a simple idea: finding and managing the right services should be
          beautiful, fast and stress-free. Today we help thousands of teams do exactly that.
        </Typography>
      </Box>

      <Grid container spacing={3} sx={{ mb: 8 }}>
        {values.map((v) => (
          <Grid key={v.title} size={{ xs: 12, md: 4 }}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Avatar sx={{ background: v.g, width: 52, height: 52, mb: 2, boxShadow: 3 }}>{v.icon}</Avatar>
                <Typography variant="h6" sx={{ fontWeight: 700 }}>{v.title}</Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>{v.desc}</Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Card sx={{ p: { xs: 3, md: 6 }, mb: 8, background: (t) => (t.palette.mode === 'dark' ? 'rgba(30,41,59,0.6)' : 'rgba(255,255,255,0.7)'), backdropFilter: 'blur(12px)' }}>
        <Grid container spacing={4} alignItems="center">
          <Grid size={{ xs: 12, md: 6 }}>
            <Typography variant="h4" sx={{ fontWeight: 800, mb: 2 }}>Our story</Typography>
            <Typography variant="body1" color="text.secondary" paragraph>
              Founded in 2024, ServiceHub Pro was born out of frustration with clunky, fragmented tools.
              We set out to design a single platform that feels as polished as the products we admire most.
            </Typography>
            <Typography variant="body1" color="text.secondary">
              From a small team of four to a thriving community of builders, our commitment has never changed:
              craft software people genuinely love to use.
            </Typography>
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <Grid container spacing={2}>
              {[['2024', 'Founded'], ['12k+', 'Users'], ['30+', 'Services'], ['4.9/5', 'Rating']].map(([v, l]) => (
                <Grid key={l} size={6}>
                  <Box sx={{ textAlign: 'center', p: 2 }}>
                    <Typography variant="h4" sx={{ fontWeight: 800, color: 'primary.main' }}>{v}</Typography>
                    <Typography variant="body2" color="text.secondary">{l}</Typography>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </Grid>
        </Grid>
      </Card>

      <Divider sx={{ mb: 6 }}>
        <Chip label="Meet the team" />
      </Divider>

      <Grid container spacing={3}>
        {team.map((m) => (
          <Grid key={m.name} size={{ xs: 6, md: 3 }}>
            <Card sx={{ textAlign: 'center', p: 3, height: '100%' }}>
              <Stack alignItems="center" spacing={1.5}>
                <Avatar src={m.avatar} alt={m.name} sx={{ width: 88, height: 88, boxShadow: 4 }} />
                <Box>
                  <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>{m.name}</Typography>
                  <Typography variant="body2" color="text.secondary">{m.role}</Typography>
                </Box>
              </Stack>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}
