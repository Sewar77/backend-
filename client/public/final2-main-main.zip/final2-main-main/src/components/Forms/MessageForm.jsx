import { useState } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button, Grid,
  TextField, MenuItem,
} from '@mui/material';

const EMPTY = { fromName: '', fromEmail: '', subject: '', body: '', status: 'unread' };
const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


export default function MessageForm({ open, initialData, mode = 'public', onSubmit, onClose }) {
  const isEdit = Boolean(initialData);
  const showSender = mode === 'public';
  const showStatus = mode === 'admin';
  const [form, setForm] = useState(() => (initialData ? { ...EMPTY, ...initialData } : EMPTY));
  const [errors, setErrors] = useState({});

  const handle = (field) => (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const validate = () => {
    const next = {};
    if (!form.subject.trim()) next.subject = 'Subject is required';
    if (!form.body.trim()) next.body = 'Message body is required';
    if (showSender) {
      if (!form.fromName.trim()) next.fromName = 'Your name is required';
      if (!emailRe.test(form.fromEmail)) next.fromEmail = 'Valid email is required';
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const submit = () => {
    if (!validate()) return;
    onSubmit({ ...form });
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth slotProps={{ paper: { sx: { borderRadius: 3 } } }}>
      <DialogTitle>{isEdit ? 'Edit message' : 'New message'}</DialogTitle>
      <DialogContent dividers>
        <Grid container spacing={2} sx={{ mt: 0 }}>
          {showSender && (
            <>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField fullWidth label="Your name" value={form.fromName} onChange={handle('fromName')} error={!!errors.fromName} helperText={errors.fromName} />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField fullWidth label="Your email" value={form.fromEmail} onChange={handle('fromEmail')} error={!!errors.fromEmail} helperText={errors.fromEmail} />
              </Grid>
            </>
          )}
          <Grid size={12}>
            <TextField fullWidth label="Subject" value={form.subject} onChange={handle('subject')} error={!!errors.subject} helperText={errors.subject} />
          </Grid>
          <Grid size={12}>
            <TextField fullWidth multiline minRows={4} label="Message" value={form.body} onChange={handle('body')} error={!!errors.body} helperText={errors.body} />
          </Grid>
          {showStatus && (
            <Grid size={12}>
              <TextField select fullWidth label="Status" value={form.status} onChange={handle('status')}>
                {['unread', 'read', 'replied'].map((s) => (
                  <MenuItem key={s} value={s} sx={{ textTransform: 'capitalize' }}>{s}</MenuItem>
                ))}
              </TextField>
            </Grid>
          )}
        </Grid>
      </DialogContent>
      <DialogActions sx={{ p: 2.5 }}>
        <Button color="inherit" onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={submit}>{isEdit ? 'Save' : 'Send message'}</Button>
      </DialogActions>
    </Dialog>
  );
}
