import { useMemo, useState } from 'react';
import {
  Box, Grid, Card, CardContent, Typography, Button, Avatar, Stack, IconButton,
  Tooltip, Chip,
} from '@mui/material';
import AddRounded from '@mui/icons-material/AddRounded';
import EditRounded from '@mui/icons-material/EditRounded';
import DeleteRounded from '@mui/icons-material/DeleteRounded';
import { useData } from '../../context/DataContext';
import { useNotification } from '../../context/NotificationContext';
import PageHeader from '../../components/PageHeader';
import CategoryForm from '../../components/Forms/CategoryForm';
import ConfirmDialog from '../../components/Modals/ConfirmDialog';
import CategoryIcon from '../../components/iconMap';

export default function AdminCategories() {
  const { categories, services, addCategory, updateCategory, deleteCategory } = useData();
  const { notify } = useNotification();

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [toDelete, setToDelete] = useState(null);

  const countByCategory = useMemo(() => {
    const map = {};
    services.forEach((s) => { map[s.categoryId] = (map[s.categoryId] ?? 0) + 1; });
    return map;
  }, [services]);

  const openCreate = () => { setEditing(null); setFormOpen(true); };
  const openEdit = (cat) => { setEditing(cat); setFormOpen(true); };

  const handleSubmit = (data) => {
    if (editing) {
      updateCategory(editing.id, data);
      notify('Category updated.', 'success');
    } else {
      addCategory(data);
      notify('Category created.', 'success');
    }
    setFormOpen(false);
  };

  const handleDelete = () => {
    deleteCategory(toDelete.id);
    notify('Category deleted.', 'info');
    setToDelete(null);
  };

  return (
    <Box>
      <PageHeader
        title="Categories"
        subtitle={`Organize services across ${categories.length} categories.`}
        action={<Button variant="contained" startIcon={<AddRounded />} onClick={openCreate}>Add category</Button>}
      />

      <Grid container spacing={3}>
        {categories.map((c) => (
          <Grid key={c.id} size={{ xs: 12, sm: 6, md: 4 }}>
            <Card sx={{ height: '100%', transition: 'transform .2s ease, box-shadow .2s ease', '&:hover': { transform: 'translateY(-4px)', boxShadow: '0 16px 36px rgba(2,6,23,0.22)' } }}>
              <CardContent>
                <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
                  <Avatar sx={{ bgcolor: c.color, width: 52, height: 52, boxShadow: 3 }}>
                    <CategoryIcon name={c.icon} />
                  </Avatar>
                  <Stack direction="row" spacing={0.5}>
                    <Tooltip title="Edit"><IconButton size="small" onClick={() => openEdit(c)}><EditRounded fontSize="small" /></IconButton></Tooltip>
                    <Tooltip title="Delete"><IconButton size="small" color="error" onClick={() => setToDelete(c)}><DeleteRounded fontSize="small" /></IconButton></Tooltip>
                  </Stack>
                </Stack>
                <Typography variant="h6" sx={{ fontWeight: 700, mt: 1.5 }}>{c.name}</Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5, minHeight: 40 }}>{c.description}</Typography>
                <Chip size="small" label={`${countByCategory[c.id] ?? 0} services`} sx={{ mt: 1 }} />
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <CategoryForm key={formOpen ? (editing?.id ?? 'new') : 'closed'} open={formOpen} initialData={editing} onSubmit={handleSubmit} onClose={() => setFormOpen(false)} />
      <ConfirmDialog
        open={Boolean(toDelete)}
        title="Delete category?"
        message={toDelete ? `"${toDelete.name}" will be permanently removed.` : ''}
        onConfirm={handleDelete}
        onClose={() => setToDelete(null)}
      />
    </Box>
  );
}
